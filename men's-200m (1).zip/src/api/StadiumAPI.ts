import * as THREE from 'three';
import { BoardManager } from '../boards/BoardManager';
import { BoardScreen, BoardSourceOptions } from '../boards/BoardScreen';
import { CameraController } from '../cameras/CameraController';
import {
  BoardMessagePayload,
  BoardName,
  BoardSourceKind,
  CameraPresetId,
  TimeOfDay,
} from '../config';
import { PeopleManager } from '../people/PeopleManager';
import {
  PersonInstance,
  PersonOptions,
  PersonPoseName,
  PersonType,
} from '../people/PersonFactory';
import { getTrackPath, TrackPath } from '../track/trackGeometry';

export interface StadiumJSONState {
  timeOfDay: TimeOfDay;
  cameraPreset: CameraPresetId;
  autoOrbit: boolean;
  crowdFillPercent: number;
  crowdDensity: number;
  cheerWave: boolean;
  debugCenterline: boolean;
  performanceMode: boolean;
  targetFps: 30 | 60;
  showLabels: boolean;
  measuredLapLengthMeters: number;
  totalSeatsBuilt: number;
  boards: Record<BoardName, BoardSourceKind>;
}

export type StadiumUpdateCallback = (elapsedSeconds: number, dt: number) => void;

export interface StadiumAPI {
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly renderer: THREE.WebGLRenderer;
  readonly state: StadiumJSONState;
  getTrackPath: (lane: number) => TrackPath;
  addUpdateCallback: (fn: StadiumUpdateCallback) => () => void;
  boards: {
    get: (name: BoardName) => BoardScreen | undefined;
    getAll: () => BoardScreen[];
    setSource: (name: BoardName, kind: BoardSourceKind, options?: BoardSourceOptions) => void;
    writeMessage: (target: BoardName | 'all', message: BoardMessagePayload) => void;
    sendDemoPostMessage: () => void;
  };
  people: {
    spawnPerson: (type: PersonType, options?: PersonOptions) => string;
    removePerson: (id: string) => boolean;
    setPose: (id: string, poseName: PersonPoseName) => boolean;
    getAll: () => PersonInstance[];
    setLabelsVisible: (visible: boolean) => void;
  };
  cameras: {
    goTo: (preset: CameraPresetId, immediate?: boolean) => void;
    setAutoOrbit: (enabled: boolean) => void;
  };
  setTimeOfDay: (tod: TimeOfDay) => void;
  setCrowdFill: (percent: number) => void;
  setCrowdDensity: (density: number) => void;
  setCheerWave: (enabled: boolean) => void;
  setDebugCenterline: (visible: boolean) => void;
  setPerformanceMode: (enabled: boolean) => void;
  setTargetFps: (fps: 30 | 60) => void;
}

declare global {
  interface Window {
    WSTV?: {
      stadium: StadiumAPI;
    };
  }
}

let activeApi: StadiumAPI | null = null;

export function getStadiumAPI(): StadiumAPI | null {
  return activeApi;
}

export function createAndRegisterStadiumAPI(deps: {
  scene: THREE.Scene;
  cameraController: CameraController;
  renderer: THREE.WebGLRenderer;
  boardManager: BoardManager;
  peopleManager: PeopleManager;
  state: StadiumJSONState;
  addUpdateCallback: (fn: StadiumUpdateCallback) => () => void;
  setTimeOfDay: (tod: TimeOfDay) => void;
  setCrowdFill: (percent: number) => void;
  setCrowdDensity: (density: number) => void;
  setCheerWave: (enabled: boolean) => void;
  setDebugCenterline: (visible: boolean) => void;
  setPerformanceMode: (enabled: boolean) => void;
  setTargetFps: (fps: 30 | 60) => void;
  onStateChanged: () => void;
}): StadiumAPI {
  const api: StadiumAPI = {
    scene: deps.scene,
    camera: deps.cameraController.camera,
    renderer: deps.renderer,
    state: deps.state,
    getTrackPath,
    addUpdateCallback: deps.addUpdateCallback,
    boards: {
      get: (name) => deps.boardManager.get(name),
      getAll: () => deps.boardManager.getAll(),
      setSource: (name, kind, options) => {
        deps.boardManager.setSource(name, kind, options);
        deps.state.boards[name] = kind;
        deps.onStateChanged();
      },
      writeMessage: (target, message) => {
        deps.boardManager.writeMessage(target, message);
        if (target === 'all') {
          (['eastBoard', 'westBoard', 'ringBoard', 'mainScoreboard'] as BoardName[]).forEach(
            (n) => {
              deps.state.boards[n] = 'message';
            }
          );
        } else {
          deps.state.boards[target] = 'message';
        }
        deps.onStateChanged();
      },
      sendDemoPostMessage: () => deps.boardManager.sendDemoPostMessage(),
    },
    people: {
      spawnPerson: (type, options) => deps.peopleManager.spawnPerson(type, options),
      removePerson: (id) => deps.peopleManager.removePerson(id),
      setPose: (id, poseName) => deps.peopleManager.setPose(id, poseName),
      getAll: () => deps.peopleManager.getAll(),
      setLabelsVisible: (visible) => {
        deps.peopleManager.setLabelsVisible(visible);
        deps.state.showLabels = visible;
        deps.onStateChanged();
      },
    },
    cameras: {
      goTo: (preset, immediate) => {
        deps.cameraController.goTo(preset, immediate);
        deps.state.cameraPreset = preset;
        deps.onStateChanged();
      },
      setAutoOrbit: (enabled) => {
        deps.cameraController.setAutoOrbit(enabled);
        deps.state.autoOrbit = enabled;
        deps.onStateChanged();
      },
    },
    setTimeOfDay: deps.setTimeOfDay,
    setCrowdFill: deps.setCrowdFill,
    setCrowdDensity: deps.setCrowdDensity,
    setCheerWave: deps.setCheerWave,
    setDebugCenterline: deps.setDebugCenterline,
    setPerformanceMode: deps.setPerformanceMode,
    setTargetFps: deps.setTargetFps,
  };

  activeApi = api;
  if (typeof window !== 'undefined') {
    window.WSTV = { stadium: api };
  }
  return api;
}

export function clearRegisteredStadiumAPI(): void {
  activeApi = null;
  if (typeof window !== 'undefined' && window.WSTV) {
    delete window.WSTV;
  }
}
