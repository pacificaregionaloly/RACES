import * as THREE from 'three';
import { STADIUM_CONFIG } from '../config';

const T = STADIUM_CONFIG.track;

export const HALF_STRAIGHT = T.straightLength / 2; // 42.195 m
export const KERB_RADIUS = T.lane1MeasuringRadius - T.lane1MeasureOffset; // 36.50 m
export const OUTER_TRACK_RADIUS = KERB_RADIUS + T.lanes * T.laneWidth; // 46.26 m

export interface LaneMetrics {
  lane: number;
  innerRadius: number;
  outerRadius: number;
  centerRadius: number;
  measuringRadius: number;
  lapLength: number;
}

export interface TrackPoint {
  position: THREE.Vector3;
  heading: number; // radians, 0 = +Z, +PI/2 = +X
  tangent: THREE.Vector3;
}

export interface TrackPath {
  lane: number;
  radius: number;
  length: number;
  pointAt: (distanceMeters: number) => TrackPoint;
}

export function getLaneMetrics(lane: number): LaneMetrics {
  const clamped = Math.max(1, Math.min(T.lanes, Math.round(lane)));
  const innerRadius = KERB_RADIUS + (clamped - 1) * T.laneWidth;
  const outerRadius = innerRadius + T.laneWidth;
  const centerRadius = innerRadius + T.laneWidth * 0.5;
  const measuringRadius =
    clamped === 1 ? T.lane1MeasuringRadius : innerRadius + T.outerLaneMeasureOffset;
  const lapLength = 2 * T.straightLength + 2 * Math.PI * measuringRadius;

  return {
    lane: clamped,
    innerRadius,
    outerRadius,
    centerRadius,
    measuringRadius,
    lapLength,
  };
}

/**
 * Generates ordered 2D (x, z) points around the complete, closed oval at a given radius.
 * Starts at the Finish Line (+HALF_STRAIGHT, +radius) and walks counterclockwise:
 * East bend -> Back straight -> West bend -> Home straight -> back to Finish Line.
 */
export function sampleClosedOvalPoints(
  radius: number,
  curveSegments = T.curveSegments
): THREE.Vector2[] {
  const pts: THREE.Vector2[] = [];

  // East semicircular bend: (+HALF_STRAIGHT, 0), phi from +PI/2 down to -PI/2
  for (let i = 0; i <= curveSegments; i++) {
    const phi = Math.PI / 2 - (i / curveSegments) * Math.PI;
    pts.push(
      new THREE.Vector2(
        HALF_STRAIGHT + radius * Math.cos(phi),
        radius * Math.sin(phi)
      )
    );
  }

  // Back straight connects (+HALF_STRAIGHT, -radius) to (-HALF_STRAIGHT, -radius)
  // West semicircular bend: (-HALF_STRAIGHT, 0), phi from -PI/2 down to -3*PI/2
  for (let i = 0; i <= curveSegments; i++) {
    const phi = -Math.PI / 2 - (i / curveSegments) * Math.PI;
    pts.push(
      new THREE.Vector2(
        -HALF_STRAIGHT + radius * Math.cos(phi),
        radius * Math.sin(phi)
      )
    );
  }

  // Home straight closes back from (-HALF_STRAIGHT, +radius) to (+HALF_STRAIGHT, +radius)
  return pts;
}

/**
 * Computes exact closed-loop polyline length from generated 2D/3D vertices (for startup self-check).
 */
export function computePolylineLapLength(points: THREE.Vector2[]): number {
  let total = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i];
    const b = points[(i + 1) % points.length];
    total += a.distanceTo(b);
  }
  return total;
}

/**
 * Extension API helper: returns a continuous closed-loop TrackPath for any lane (1..8).
 * Distance 0 = start of the home straight (-HALF_STRAIGHT, +centerRadius), moving +X toward Finish Line,
 * then around East Bend, Back Straight, West Bend, and returning smoothly to Distance 0.
 */
export function getTrackPath(lane: number): TrackPath {
  const m = getLaneMetrics(lane);
  const visR = m.centerRadius;
  const measR = m.measuringRadius;
  const curveLen = Math.PI * measR;
  const lapLen = 2 * T.straightLength + 2 * curveLen;

  const pointAt = (distanceMeters: number): TrackPoint => {
    let s = distanceMeters % lapLen;
    if (s < 0) s += lapLen;

    // 1. Home Straight: (-HALF_STRAIGHT, +visR) -> (+HALF_STRAIGHT, +visR)
    if (s < T.straightLength) {
      const x = -HALF_STRAIGHT + s;
      const z = visR;
      const tangent = new THREE.Vector3(1, 0, 0);
      return {
        position: new THREE.Vector3(x, T.trackSurfaceY, z),
        heading: Math.PI / 2,
        tangent,
      };
    }
    s -= T.straightLength;

    // 2. East Bend: phi from +PI/2 down to -PI/2
    if (s < curveLen) {
      const phi = Math.PI / 2 - (s / curveLen) * Math.PI;
      const x = HALF_STRAIGHT + visR * Math.cos(phi);
      const z = visR * Math.sin(phi);
      const tx = Math.sin(phi);
      const tz = -Math.cos(phi);
      return {
        position: new THREE.Vector3(x, T.trackSurfaceY, z),
        heading: Math.atan2(tx, tz),
        tangent: new THREE.Vector3(tx, 0, tz).normalize(),
      };
    }
    s -= curveLen;

    // 3. Back Straight: (+HALF_STRAIGHT, -visR) -> (-HALF_STRAIGHT, -visR)
    if (s < T.straightLength) {
      const x = HALF_STRAIGHT - s;
      const z = -visR;
      const tangent = new THREE.Vector3(-1, 0, 0);
      return {
        position: new THREE.Vector3(x, T.trackSurfaceY, z),
        heading: -Math.PI / 2,
        tangent,
      };
    }
    s -= T.straightLength;

    // 4. West Bend: phi from -PI/2 down to -3*PI/2
    const phi = -Math.PI / 2 - (s / curveLen) * Math.PI;
    const x = -HALF_STRAIGHT + visR * Math.cos(phi);
    const z = visR * Math.sin(phi);
    const tx = Math.sin(phi);
    const tz = -Math.cos(phi);
    return {
      position: new THREE.Vector3(x, T.trackSurfaceY, z),
      heading: Math.atan2(tx, tz),
      tangent: new THREE.Vector3(tx, 0, tz).normalize(),
    };
  };

  return {
    lane: m.lane,
    radius: visR,
    length: lapLen,
    pointAt,
  };
}
