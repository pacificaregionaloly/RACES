import React, { useState } from 'react';
import { Monitor, Radio, RotateCcw, Send, Type, X } from 'lucide-react';
import { StadiumAPI, StadiumJSONState } from '../api/StadiumAPI';
import { BoardMessageTheme, BoardName, BoardSourceKind } from '../config';

interface BoardsPanelProps {
  api: StadiumAPI | null;
  state: StadiumJSONState;
  onClose: () => void;
}

const BOARD_LABELS: { id: BoardName; label: string }[] = [
  { id: 'mainScoreboard', label: 'Main Scoreboard' },
  { id: 'eastBoard', label: 'East End Board' },
  { id: 'westBoard', label: 'West End Board' },
  { id: 'ringBoard', label: '360° Ring Fascia' },
];

const SOURCES: { id: BoardSourceKind; label: string }[] = [
  { id: 'message', label: 'Message' },
  { id: 'demo', label: 'Demo Loop' },
  { id: 'canvas2d', label: 'Canvas 2D' },
  { id: 'video', label: 'Video Tex' },
  { id: 'renderTarget', label: '3D RenderTarget' },
  { id: 'postMessage', label: 'postMessage' },
];

const THEMES: { id: BoardMessageTheme; label: string; dot: string }[] = [
  { id: 'royal', label: 'Royal Blue', dot: 'bg-[#0033a0]' },
  { id: 'gold', label: 'Olympic Gold', dot: 'bg-[#d4af37]' },
  { id: 'alert', label: 'Alert Red', dot: 'bg-[#dc2626]' },
];

export const BoardsPanel: React.FC<BoardsPanelProps> = ({ api, state, onClose }) => {
  const [target, setTarget] = useState<BoardName | 'all'>('all');
  const [title, setTitle] = useState('WELCOME TO KLEMONSERRAT STADIUM');
  const [body, setBody] = useState(
    '1st Pacifica Regional Olympics 2026 · Plead City, New Pleadland'
  );
  const [theme, setTheme] = useState<BoardMessageTheme>('royal');

  if (!api) return null;

  const setAll = (kind: BoardSourceKind) => {
    BOARD_LABELS.forEach((b) => api.boards.setSource(b.id, kind));
  };

  const handlePublishMessage = (e: React.FormEvent) => {
    e.preventDefault();
    api.boards.writeMessage(target, {
      title,
      body,
      theme,
    });
  };

  const handleResetDemo = () => {
    setAll('demo');
  };

  return (
    <aside
      aria-label="Stadium Video Boards and Message Writer"
      className="fixed right-3 top-16 z-30 w-[360px] max-w-[calc(100vw-24px)] max-h-[calc(100vh-140px)] overflow-y-auto custom-scroll rounded-xl border border-[#d4af37]/45 bg-[#041029]/95 p-4 text-slate-100 shadow-2xl"
    >
      <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2">
          <Monitor className="h-4 w-4 text-[#f5c542]" />
          <h2 className="font-display text-base font-bold tracking-wide uppercase text-white">
            Stadium Boards &amp; Messages
          </h2>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Boards Panel"
          className="rounded-md p-1 text-slate-400 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Write Custom Message Composer */}
      <form
        onSubmit={handlePublishMessage}
        className="mt-3 rounded-lg border border-[#d4af37]/35 bg-[#07183c] p-3 space-y-2.5"
      >
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs font-bold tracking-wide text-[#f5c542] uppercase">
            <Type className="h-3.5 w-3.5" />
            Write Message on Boards
          </span>
          <select
            aria-label="Target Board"
            value={target}
            onChange={(e) => setTarget(e.target.value as BoardName | 'all')}
            className="rounded border border-white/15 bg-[#041029] px-2 py-0.5 text-[11px] font-medium text-white focus:border-[#f5c542] focus:outline-none"
          >
            <option value="all">All 4 Boards</option>
            {BOARD_LABELS.map((b) => (
              <option key={b.id} value={b.id}>
                {b.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Headline
          </label>
          <input
            type="text"
            value={title}
            maxLength={72}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.stopPropagation()}
            placeholder="Type headline for stadium boards..."
            className="select-text w-full rounded-md border border-white/15 bg-[#041029] px-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:border-[#f5c542] focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Message / Announcement
          </label>
          <textarea
            rows={2}
            value={body}
            maxLength={180}
            onChange={(e) => setBody(e.target.value)}
            onKeyDown={(e) => e.stopPropagation()}
            placeholder="Type message body or ring ticker text..."
            className="select-text w-full resize-none rounded-md border border-white/15 bg-[#041029] px-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:border-[#f5c542] focus:outline-none"
          />
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1" role="group" aria-label="Board Message Theme">
            {THEMES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTheme(t.id)}
                className={`flex items-center gap-1 rounded px-2 py-1 text-[10px] font-semibold transition-colors ${
                  theme === t.id
                    ? 'bg-[#0033a0] text-white ring-1 ring-[#f5c542]'
                    : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                }`}
              >
                <span className={`inline-block h-2 w-2 rounded-full ${t.dot}`} />
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 pt-0.5">
          <button
            type="submit"
            className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#d4af37] px-3 py-1.5 text-xs font-bold text-[#041029] hover:bg-[#f5c542] focus-visible:outline-2 focus-visible:outline-white"
          >
            <Send className="h-3.5 w-3.5" />
            Display on Boards
          </button>
          <button
            type="button"
            onClick={handleResetDemo}
            title="Reset all boards to default Demo Loop"
            className="flex items-center gap-1 rounded-lg border border-white/15 bg-[#041029] px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-white/10"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Demo
          </button>
        </div>
      </form>

      {/* Source Switcher */}
      <div className="mt-3.5 flex flex-wrap gap-1.5">
        <span className="w-full text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
          Switch All Board Sources
        </span>
        {SOURCES.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() =>
              s.id === 'message'
                ? api.boards.writeMessage('all', { title, body, theme })
                : setAll(s.id)
            }
            className="rounded border border-white/15 bg-[#0a214d] px-2 py-1 text-[11px] font-medium text-slate-200 hover:border-[#f5c542]/60 hover:bg-[#0033a0] focus-visible:outline-2 focus-visible:outline-[#f5c542]"
          >
            {s.label}
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-2">
        {BOARD_LABELS.map((b) => {
          const active = state.boards[b.id];
          return (
            <div
              key={b.id}
              className="rounded-lg border border-white/10 bg-[#07183c] p-2.5"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">{b.label}</span>
                <span className="font-mono text-[10px] text-[#f5c542] uppercase">
                  {active}
                </span>
              </div>
              <div className="mt-1.5 grid grid-cols-3 gap-1">
                {SOURCES.map((src) => {
                  const isActive = active === src.id;
                  return (
                    <button
                      key={src.id}
                      type="button"
                      onClick={() =>
                        src.id === 'message'
                          ? api.boards.writeMessage(b.id, { title, body, theme })
                          : api.boards.setSource(b.id, src.id)
                      }
                      className={`rounded px-1.5 py-1 text-[10px] font-medium transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                        isActive
                          ? 'bg-[#0033a0] text-white ring-1 ring-[#f5c542]'
                          : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      {src.label}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-3 flex items-center justify-between gap-2 border-t border-white/10 pt-3">
        <button
          type="button"
          onClick={() => {
            setAll('postMessage');
            api.boards.sendDemoPostMessage();
          }}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-[#d4af37]/50 bg-[#07183c] px-3 py-1.5 text-xs font-semibold text-[#f5c542] hover:bg-[#0033a0] focus-visible:outline-2 focus-visible:outline-white"
        >
          <Radio className="h-3.5 w-3.5" />
          Send Test postMessage
        </button>
      </div>
    </aside>
  );
};
