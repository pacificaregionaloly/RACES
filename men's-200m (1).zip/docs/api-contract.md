# Wavesports API Contract — Men's 100 Metres (WSTV)

This specification defines the backend HTTP / Realtime API consumed by the **Men's 100m Event Module** (`event/api/WavesportsApiClient.ts`) for Klemonserrat Stadium (1st Pacifica Regional Olympics 2026).

---

## Authentication & Configuration

All requests (except optional SSE/EventSource streams) include:

```http
Authorization: Bearer <API_TOKEN>
Content-Type: application/json
Accept: application/json
```

Client configuration (`event/config/index.ts`):
- `API_BASE_URL` — Base URL (default `/api/wavesports`, or `VITE_WAVESPORTS_API_BASE_URL`, or `?apiBase=...`)
- `API_TOKEN` — Bearer token (`VITE_WAVESPORTS_API_TOKEN`)
- `RACE_ID` — Active race identifier (default `men-100m-final-1`, or `?race=...`)
- `POLL_INTERVAL_MS` — Polling interval in ms (default `2500`, or `VITE_WAVESPORTS_POLL_MS`)

---

## Endpoints

### 1. Fetch Race Setup
`GET {API_BASE_URL}/races/{raceId}/setup`

Returns the authoritative race configuration, rules, deterministic `seed`, and athlete roster. The client remains in `WAITING_FOR_API` until this endpoint returns HTTP 200 with a payload passing all validation checks.

#### Setup Payload Schema
```json
{
  "raceId": "men-100m-final-1",
  "event": "men_100m",
  "round": "final",
  "heat": 1,
  "seed": 482913,
  "scheduledStartTime": "2026-12-05T15:30:00Z",
  "allowManualStart": false,
  "venue": "Klemonserrat Stadium",
  "rules": {
    "falseStartDisqualifies": true,
    "windLimitMps": 2.0
  },
  "incidentOverrides": null,
  "athletes": [
    {
      "athleteId": "ath_001",
      "lane": 4,
      "name": "Kaelen Tuiasosopo",
      "shortName": "TUIASOSOPO",
      "nation": "New Pleadland",
      "nationCode": "NPL",
      "bib": "104",
      "kit": {
        "primary": "#0033A0",
        "secondary": "#FFFFFF",
        "accent": "#D4AF37"
      },
      "ratings": {
        "reaction": 86,
        "acceleration": 91,
        "topSpeed": 94,
        "speedEndurance": 89,
        "consistency": 88,
        "composure": 85,
        "durability": 86,
        "technique": 90
      },
      "personalBest": 9.84,
      "seasonBest": 9.89,
      "status": "active"
    }
  ]
}
```

#### Validation Rules (Client-Enforced)
If any check fails, the client rejects the payload, stays in `WAITING_FOR_API`, displays an error, retries with exponential backoff, and attempts to POST `VALIDATION_FAILED` to `/status`:
- `athletes`: array of **2 to 8** entries
- `lane`: unique integers **1 to 8**
- `ratings`: all 8 fields (`reaction`, `acceleration`, `topSpeed`, `speedEndurance`, `consistency`, `composure`, `durability`, `technique`) must be finite numbers in **0..100**
- `seed`: must be an **integer**
- `event`: must equal `"men_100m"`
- `status`: must be `"active"` or `"dns"` (DNS athletes stay in the call room and are reported as `DNS`)
- `kit`: `{ primary, secondary, accent }` color strings required

#### Optional `incidentOverrides` Object
Pass `null` for default probabilities, or override any subset (set all to `0` to guarantee a clean race):
```json
{
  "falseStartBaseRate": 0.028,
  "stumbledStartRate": 0.035,
  "fallOrTripRate": 0.012,
  "injuryPullUpRate": 0.010,
  "laneViolationRate": 0.008,
  "collisionBrushRate": 0.006,
  "lateDnsRate": 0.005,
  "equipmentBlockSlipRate": 0.007,
  "breakoutPerformanceRate": 0.045,
  "maxRecalls": 3
}
```

---

### 2. Poll or Stream Race Commands
- HTTP Polling: `GET {API_BASE_URL}/races/{raceId}/commands?since={ISO-8601}`
- Optional SSE (`?realtime=sse`): `GET {API_BASE_URL}/races/{raceId}/commands/stream`
- Optional WebSocket (`?realtime=ws`): `WS {API_BASE_URL}/races/{raceId}/commands/ws`

Returns a single command object or an array of pending commands (`204 No Content` / `[]` when idle):

```json
{ "command": "start", "issuedAt": "2026-12-05T15:30:00Z" }
```
```json
{ "command": "abort", "reason": "Track obstruction" }
```
```json
{ "command": "reset" }
```

---

### 3. Post Race Status Updates
`POST {API_BASE_URL}/races/{raceId}/status`

Client emits lifecycle status transitions and incident alerts:
```json
{ "status": "VALIDATED", "timestamp": "2026-12-05T15:29:45Z" }
{ "status": "ATHLETES_ON_TRACK", "timestamp": "..." }
{ "status": "READY", "timestamp": "..." }
{ "status": "ON_YOUR_MARKS", "timestamp": "..." }
{ "status": "SET", "timestamp": "..." }
{ "status": "FALSE_START", "athleteId": "ath_006", "detail": "...", "timestamp": "..." }
{ "status": "RUNNING", "timestamp": "..." }
{ "status": "RESULTS_POSTED", "timestamp": "..." }
{ "status": "VALIDATION_FAILED", "detail": "...", "timestamp": "..." }
```

---

### 4. Post Final Results
`POST {API_BASE_URL}/races/{raceId}/results`

Sent automatically when the race transitions to `FINISHED`, moving the state machine to `RESULTS_POSTED`:

```json
{
  "raceId": "men-100m-final-1",
  "seed": 482913,
  "completedAt": "2026-12-05T15:30:14Z",
  "wind": { "mps": 0.8, "legal": true },
  "incidents": [
    {
      "type": "false_start",
      "code": "FALSE_START_UNDER_100MS",
      "athleteId": "ath_006",
      "lane": 6,
      "attempt": 0,
      "atTime": -0.062,
      "detail": "Tane Te Aho (Lane 6) reacted at -0.062s (< 0.100s threshold)."
    }
  ],
  "results": [
    {
      "rank": 1,
      "lane": 4,
      "athleteId": "ath_004",
      "name": "Kaelen Tuiasosopo",
      "shortName": "TUIASOSOPO",
      "nation": "New Pleadland",
      "nationCode": "NPL",
      "bib": "104",
      "time": 9.87,
      "exactTime": 9.874,
      "reactionTime": 0.142,
      "splits": { "20": 2.89, "40": 4.9, "60": 6.8, "80": 8.8 },
      "topSpeedMps": 12.14,
      "status": "finished",
      "notes": []
    },
    {
      "rank": null,
      "lane": 6,
      "athleteId": "ath_006",
      "name": "Tane Te Aho",
      "shortName": "TE AHO",
      "nation": "New Zealand",
      "nationCode": "NZL",
      "bib": "106",
      "status": "DQ",
      "reason": "false_start",
      "notes": ["Disqualified (Attempt #1): false_start"]
    }
  ]
}
```
