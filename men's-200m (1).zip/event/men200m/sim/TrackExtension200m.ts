import * as THREE from 'three';
import type { StadiumAPI } from '../../../src/api/StadiumAPI';
import type { TrackPoint } from '../../../src/track/trackGeometry';

export const EVENT_LAYER_NAME_200M = 'EventLayer_Men200m';
export const RACE_DISTANCE_METERS_200M = 200.0;
export const TRACK_SURFACE_Y = 0.04;
export const LANE_WIDTH = 1.22;
export const LINE_WIDTH = 0.05;
/** Running line is 0.20 m from the lane's inside line (0.20 m from curb for Lane 1). */
export const RUNNING_LINE_INSIDE_OFFSET = 0.20;
/** Stadium's getTrackPath returns lane center line (0.61 m from lane's inside line). */
export const LANE_CENTER_TO_RUNNING_OFFSET =
  LANE_WIDTH * 0.5 - RUNNING_LINE_INSIDE_OFFSET; // 0.41 m inward

export interface EventTrackPoint200m extends TrackPoint {
  onBend: boolean;
  bendRadiusM: number;
}

export interface EventLanePath200m {
  lane: number;
  runningRadius: number;
  laneCenterRadius: number;
  homeStraightLength: number;
  bendExitDistanceM: number;
  westBendArcLengthM: number;
  startPoint: EventTrackPoint200m;
  finishPoint: EventTrackPoint200m;
  pointAtRaceDistance: (
    raceDistanceMeters: number,
    lateralOffsetM?: number
  ) => EventTrackPoint200m;
}

export interface LaneStaggerCheck {
  lane: number;
  runningRadiusM: number;
  measuredLengthM: number;
  errorM: number;
  withinTolerance: boolean;
  staggerAheadOfLane1M: number;
  staggerDeltaFromPrevM: number;
  startsOnBend: boolean;
}

export interface StaggerSelfCheckResult {
  passed: boolean;
  toleranceM: number;
  homeStraightLengthM: number;
  bendExitDistanceM: number;
  lanes: LaneStaggerCheck[];
  failureReason: string | null;
}

function createStartLaneNumberTexture(
  lane: number,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 88px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(lane), 64, 68);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createWindGaugeTexture(windText: string, legal: boolean): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  drawWindGaugeCanvas(canvas, windText, legal);
  return canvas;
}

function drawWindGaugeCanvas(
  canvas: HTMLCanvasElement,
  windText: string,
  legal: boolean
): void {
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#041029';
  ctx.fillRect(0, 0, 256, 128);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 4;
  ctx.strokeRect(4, 4, 248, 120);

  ctx.fillStyle = '#93C5FD';
  ctx.font = 'bold 20px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('WSTV WIND GAUGE · 200M', 128, 28);

  ctx.fillStyle = legal ? '#4ADE80' : '#FBBF24';
  ctx.font = 'bold 48px "JetBrains Mono", monospace';
  ctx.fillText(windText, 128, 78);

  ctx.fillStyle = '#E2E8F0';
  ctx.font = 'bold 16px "Barlow Condensed", sans-serif';
  ctx.fillText(
    legal ? 'LEGAL (<= +2.0 m/s)' : 'WIND-AIDED (> +2.0 m/s)',
    128,
    108
  );
}

/**
 * Additive Men's 200m staggered-start geometry, angled blocks, lane numbers,
 * starter stand, wind gauge, wind flags, and recall cones placed inside
 * `THREE.Group('EventLayer_Men200m')`. Read-only wrt stadium objects.
 */
export class EventTrackLayer200m {
  public readonly group: THREE.Group;
  public readonly selfCheck: StaggerSelfCheckResult;
  private readonly stadium: StadiumAPI;
  private readonly lanePaths = new Map<number, EventLanePath200m>();
  private readonly blockLedMaterials = new Map<number, THREE.MeshStandardMaterial>();
  private readonly windFlags: Array<{ pivot: THREE.Group; cloth: THREE.Mesh }> = [];
  private readonly recallConesGroup = new THREE.Group();
  private readonly gunFlashMesh: THREE.Mesh;
  private readonly gunSmokeMesh: THREE.Mesh;
  private readonly windGaugeCanvas: HTMLCanvasElement;
  private readonly windGaugeTex: THREE.CanvasTexture;
  private readonly disposables: Array<{ dispose: () => void }> = [];

  private gunFxTimer = -1;
  private windMps = 0;

  constructor(stadium: StadiumAPI) {
    this.stadium = stadium;
    this.group = new THREE.Group();
    this.group.name = EVENT_LAYER_NAME_200M;

    const maxAnisotropy = Math.min(8, stadium.renderer.capabilities.getMaxAnisotropy());

    // 1. Derive each lane's running line (0.20 m from inside line / curb) from stadium.getTrackPath(lane)
    const lane1Path = stadium.getTrackPath(1);
    const homeEntryPt1 = lane1Path.pointAt(0);
    // Home straight length is derived from the stadium's own straight between x=-HALF and x=+HALF
    const homeStraightLength = Math.abs(homeEntryPt1.position.x) * 2; // 84.39 m
    const bendExitDistanceM = RACE_DISTANCE_METERS_200M - homeStraightLength; // 115.61 m
    const homeEntryX = homeEntryPt1.position.x; // -42.195
    const finishLineX = homeEntryX + homeStraightLength; // +42.195

    const laneChecks: LaneStaggerCheck[] = [];
    let allLanesCover200 = true;
    let firstFailure: string | null = null;

    for (let lane = 1; lane <= 8; lane++) {
      const stadiumPath = stadium.getTrackPath(lane);
      if (stadiumPath.length < RACE_DISTANCE_METERS_200M) {
        allLanesCover200 = false;
        firstFailure = `Stadium track path for Lane ${lane} is only ${stadiumPath.length.toFixed(
          2
        )} m (< 200.00 m).`;
      }

      // Stadium path positions lie on the lane center line; offset inward by 0.41 m to 0.20 m running line
      const laneCenterRadius = stadiumPath.radius;
      const runningRadius = laneCenterRadius - LANE_CENTER_TO_RUNNING_OFFSET;
      const westBendArcLengthM = Math.PI * runningRadius;

      const pointAtRaceDistance = (
        raceDist: number,
        lateralOffsetM = 0
      ): EventTrackPoint200m => {
        const effR = runningRadius + lateralOffsetM;

        if (raceDist >= bendExitDistanceM) {
          // Home straight (and East bend run-out if raceDist > 200m)
          const s = raceDist - bendExitDistanceM;
          if (s <= homeStraightLength) {
            return {
              position: new THREE.Vector3(homeEntryX + s, TRACK_SURFACE_Y, effR),
              heading: Math.PI / 2,
              tangent: new THREE.Vector3(1, 0, 0),
              onBend: false,
              bendRadiusM: effR,
            };
          }
          // Beyond finish line: follow stadiumPath into East bend, offset inward to running line
          const pt = stadiumPath.pointAt(s);
          const outX = -pt.tangent.z;
          const outZ = pt.tangent.x;
          const offsetFromCenter = -LANE_CENTER_TO_RUNNING_OFFSET + lateralOffsetM;
          return {
            position: new THREE.Vector3(
              pt.position.x + outX * offsetFromCenter,
              TRACK_SURFACE_Y,
              pt.position.z + outZ * offsetFromCenter
            ),
            heading: pt.heading,
            tangent: pt.tangent.clone(),
            onBend: true,
            bendRadiusM: effR,
          };
        }

        const arcBackFromHomeEntry = bendExitDistanceM - raceDist;
        if (arcBackFromHomeEntry <= westBendArcLengthM) {
          // On the West Bend: stepping backward from Home Straight entry (phi = +PI/2)
          // toward Back Straight exit (phi = +3*PI/2, equivalent to -PI/2)
          const phi =
            Math.PI / 2 + (arcBackFromHomeEntry / westBendArcLengthM) * Math.PI;
          const x = homeEntryX + effR * Math.cos(phi);
          const z = effR * Math.sin(phi);
          const tx = Math.sin(phi);
          const tz = -Math.cos(phi);
          return {
            position: new THREE.Vector3(x, TRACK_SURFACE_Y, z),
            heading: Math.atan2(tx, tz),
            tangent: new THREE.Vector3(tx, 0, tz).normalize(),
            onBend: true,
            bendRadiusM: effR,
          };
        }

        // Back straight just before West Bend entry (occurs only in Lane 1 for ~0.31 m)
        const backStraightDist = arcBackFromHomeEntry - westBendArcLengthM;
        return {
          position: new THREE.Vector3(
            homeEntryX + backStraightDist,
            TRACK_SURFACE_Y,
            -effR
          ),
          heading: -Math.PI / 2,
          tangent: new THREE.Vector3(-1, 0, 0),
          onBend: false,
          bendRadiusM: effR,
        };
      };

      const startPoint = pointAtRaceDistance(0);
      const finishPoint = pointAtRaceDistance(RACE_DISTANCE_METERS_200M);

      this.lanePaths.set(lane, {
        lane,
        runningRadius,
        laneCenterRadius,
        homeStraightLength,
        bendExitDistanceM,
        westBendArcLengthM,
        startPoint,
        finishPoint,
        pointAtRaceDistance,
      });

      // High-resolution polyline self-check from d = 0.00 to d = 200.00 m
      const samples = 1000;
      let measuredLengthM = 0;
      let prevPt = pointAtRaceDistance(0).position;
      for (let i = 1; i <= samples; i++) {
        const d = (i / samples) * RACE_DISTANCE_METERS_200M;
        const curPt = pointAtRaceDistance(d).position;
        measuredLengthM += prevPt.distanceTo(curPt);
        prevPt = curPt;
      }

      const errorM = measuredLengthM - RACE_DISTANCE_METERS_200M;
      const withinTolerance = Math.abs(errorM) <= 0.01;
      if (!withinTolerance && !firstFailure) {
        firstFailure = `Lane ${lane} running line measured ${measuredLengthM.toFixed(
          4
        )} m (outside 200.00 ± 0.01 m).`;
      }

      // Compute stagger along oval relative to Lane 1's start angle
      // Lane 1 start sits (bendExitDistanceM - PI * R_1) behind West Bend entry;
      // Lane L start sits (PI * R_L - bendExitDistanceM) past West Bend entry.
      const lane1R = this.lanePaths.get(1)!.runningRadius;
      const lane1BehindEntry = bendExitDistanceM - Math.PI * lane1R; // +0.3135 m
      const laneLPastEntry = westBendArcLengthM - bendExitDistanceM; // e.g. +3.519 m for L2
      const staggerAheadOfLane1M =
        lane === 1 ? 0 : lane1BehindEntry + laneLPastEntry;
      const prevStagger =
        lane === 1 ? 0 : laneChecks[lane - 2].staggerAheadOfLane1M;

      laneChecks.push({
        lane,
        runningRadiusM: runningRadius,
        measuredLengthM,
        errorM,
        withinTolerance,
        staggerAheadOfLane1M,
        staggerDeltaFromPrevM: lane === 1 ? 0 : staggerAheadOfLane1M - prevStagger,
        startsOnBend: bendExitDistanceM <= westBendArcLengthM,
      });
    }

    const passed =
      allLanesCover200 && laneChecks.every((c) => c.withinTolerance);

    this.selfCheck = {
      passed,
      toleranceM: 0.01,
      homeStraightLengthM: homeStraightLength,
      bendExitDistanceM,
      lanes: laneChecks,
      failureReason: passed ? null : firstFailure,
    };

    console.info(
      `[Men200m Stagger Self-Check] ${passed ? 'PASSED' : 'FAILED'} — Lanes 1-8 lengths:`,
      laneChecks.map((c) => `L${c.lane}=${c.measuredLengthM.toFixed(4)}m (+${c.staggerAheadOfLane1M.toFixed(2)}m)`).join(', ')
    );

    // 2. Additive Staggered Start Lines, Lane Numbers & Angled Starting Blocks
    const lineMat = new THREE.MeshBasicMaterial({
      color: '#FFFFFF',
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    const metalMat = new THREE.MeshStandardMaterial({
      color: '#CBD5E1',
      metalness: 0.78,
      roughness: 0.25,
    });
    const pedalMat = new THREE.MeshStandardMaterial({
      color: '#0F172A',
      roughness: 0.65,
      metalness: 0.25,
    });
    const padMat = new THREE.MeshStandardMaterial({
      color: '#0033A0',
      roughness: 0.8,
      metalness: 0.05,
    });
    this.disposables.push(lineMat, metalMat, pedalMat, padMat);

    // Each lane's start line spans the full 1.22 m lane width perpendicular to its tangent
    const startLineGeo = new THREE.PlaneGeometry(0.06, LANE_WIDTH - 0.04);
    startLineGeo.rotateX(-Math.PI / 2);
    const numPlaneGeo = new THREE.PlaneGeometry(0.72, 0.72);
    numPlaneGeo.rotateX(-Math.PI / 2);
    const railGeo = new THREE.BoxGeometry(0.86, 0.035, 0.09);
    const pedalGeo = new THREE.BoxGeometry(0.14, 0.14, 0.12);
    const sensorGeo = new THREE.BoxGeometry(0.12, 0.06, 0.14);
    const ledGeo = new THREE.BoxGeometry(0.04, 0.025, 0.06);
    const coneGeo = new THREE.ConeGeometry(0.13, 0.34, 10);
    const redConeMat = new THREE.MeshStandardMaterial({
      color: '#DC2626',
      emissive: '#991B1B',
      emissiveIntensity: 0.4,
      roughness: 0.45,
    });
    this.disposables.push(
      startLineGeo,
      numPlaneGeo,
      railGeo,
      pedalGeo,
      sensorGeo,
      ledGeo,
      coneGeo,
      redConeMat
    );

    for (let lane = 1; lane <= 8; lane++) {
      const lp = this.lanePaths.get(lane)!;
      // Place white start line centered on the lane's center radius (offset +0.41 m outward from running line)
      const startCenterPt = lp.pointAtRaceDistance(0, LANE_CENTER_TO_RUNNING_OFFSET);
      const startLineMesh = new THREE.Mesh(startLineGeo, lineMat);
      startLineMesh.position.set(
        startCenterPt.position.x,
        TRACK_SURFACE_Y + 0.006,
        startCenterPt.position.z
      );
      // Local +X of PlaneGeometry aligns with tangent when rotation.y = heading - PI/2
      startLineMesh.rotation.y = startCenterPt.heading - Math.PI / 2;
      startLineMesh.name = `StartLine200m_Lane${lane}`;
      this.group.add(startLineMesh);

      // Painted Lane Number 0.75 m ahead of the staggered start line
      const numPt = lp.pointAtRaceDistance(0.75, LANE_CENTER_TO_RUNNING_OFFSET);
      const numTex = createStartLaneNumberTexture(lane, maxAnisotropy);
      this.disposables.push(numTex);
      const numMat = new THREE.MeshBasicMaterial({
        map: numTex,
        transparent: true,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3,
      });
      this.disposables.push(numMat);

      const numMesh = new THREE.Mesh(numPlaneGeo, numMat);
      numMesh.position.set(numPt.position.x, TRACK_SURFACE_Y + 0.007, numPt.position.z);
      numMesh.rotation.y = numPt.heading - Math.PI / 2;
      this.group.add(numMesh);

      // Angled Starting Blocks positioned 0.52 m behind the staggered start line along bend tangent
      const blockPt = lp.pointAtRaceDistance(-0.52, 0);
      const blockGroup = new THREE.Group();
      blockGroup.name = `StartingBlock200m_Lane${lane}`;
      blockGroup.position.set(blockPt.position.x, TRACK_SURFACE_Y, blockPt.position.z);
      blockGroup.rotation.y = blockPt.heading - Math.PI / 2;

      const rail = new THREE.Mesh(railGeo, metalMat);
      rail.position.set(0, 0.018, 0);
      rail.castShadow = true;
      blockGroup.add(rail);

      const frontPedal = new THREE.Mesh(pedalGeo, pedalMat);
      frontPedal.position.set(0.16, 0.08, -0.11);
      frontPedal.rotation.z = -0.52;
      frontPedal.castShadow = true;
      blockGroup.add(frontPedal);

      const frontPad = new THREE.Mesh(pedalGeo, padMat);
      frontPad.scale.set(0.3, 0.92, 0.9);
      frontPad.position.set(0.18, 0.09, -0.11);
      frontPad.rotation.z = -0.52;
      blockGroup.add(frontPad);

      const rearPedal = new THREE.Mesh(pedalGeo, pedalMat);
      rearPedal.position.set(-0.18, 0.085, 0.11);
      rearPedal.rotation.z = -0.62;
      rearPedal.castShadow = true;
      blockGroup.add(rearPedal);

      const sensorPod = new THREE.Mesh(sensorGeo, pedalMat);
      sensorPod.position.set(-0.42, 0.03, 0);
      blockGroup.add(sensorPod);

      const ledMat = new THREE.MeshStandardMaterial({
        color: '#22C55E',
        emissive: '#16A34A',
        emissiveIntensity: 0.7,
        roughness: 0.3,
      });
      this.disposables.push(ledMat);
      this.blockLedMaterials.set(lane, ledMat);

      const ledMesh = new THREE.Mesh(ledGeo, ledMat);
      ledMesh.position.set(-0.42, 0.065, 0);
      blockGroup.add(ledMesh);

      this.group.add(blockGroup);

      // Recall cones (4.2 m ahead of each lane's staggered start line, hidden until recall)
      const rcPt = lp.pointAtRaceDistance(4.2, LANE_CENTER_TO_RUNNING_OFFSET);
      const rc = new THREE.Mesh(coneGeo, redConeMat);
      rc.position.set(rcPt.position.x, TRACK_SURFACE_Y + 0.17, rcPt.position.z);
      this.recallConesGroup.add(rc);
    }

    this.recallConesGroup.visible = false;
    this.group.add(this.recallConesGroup);

    // 3. Starter Stand + Gun Flash & Smoke on outer apron of the West Bend near staggered starts
    const lane8Start = this.lanePaths.get(8)!.pointAtRaceDistance(-2.0, 2.5);
    const starterGroup = new THREE.Group();
    starterGroup.name = 'StarterStand200m';
    starterGroup.position.set(
      lane8Start.position.x,
      TRACK_SURFACE_Y,
      lane8Start.position.z
    );
    starterGroup.rotation.y = lane8Start.heading - Math.PI / 2;

    const standBase = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.28, 0.9),
      new THREE.MeshStandardMaterial({ color: '#0033A0', roughness: 0.6 })
    );
    standBase.position.y = 0.14;
    standBase.castShadow = true;
    const standRim = new THREE.Mesh(
      new THREE.BoxGeometry(1.14, 0.06, 0.94),
      new THREE.MeshStandardMaterial({
        color: '#D4AF37',
        metalness: 0.6,
        roughness: 0.3,
      })
    );
    standRim.position.y = 0.28;
    const micPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025, 0.03, 1.35, 8),
      metalMat
    );
    micPole.position.set(0.35, 0.85, -0.3);
    this.disposables.push(
      standBase.geometry,
      standBase.material as THREE.Material,
      standRim.geometry,
      standRim.material as THREE.Material,
      micPole.geometry
    );
    starterGroup.add(standBase, standRim, micPole);

    const flashGeo = new THREE.SphereGeometry(0.26, 10, 10);
    const flashMat = new THREE.MeshBasicMaterial({
      color: '#FEF08A',
      transparent: true,
      opacity: 0.95,
    });
    this.gunFlashMesh = new THREE.Mesh(flashGeo, flashMat);
    this.gunFlashMesh.position.set(0.15, 1.65, -0.35);
    this.gunFlashMesh.visible = false;

    const smokeGeo = new THREE.SphereGeometry(0.38, 10, 10);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: '#E2E8F0',
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.gunSmokeMesh = new THREE.Mesh(smokeGeo, smokeMat);
    this.gunSmokeMesh.position.set(0.15, 1.75, -0.35);
    this.gunSmokeMesh.visible = false;
    this.disposables.push(flashGeo, flashMat, smokeGeo, smokeMat);
    starterGroup.add(this.gunFlashMesh, this.gunSmokeMesh);
    this.group.add(starterGroup);

    // 4. Wind Gauge Tripod & LED Display on home straight infield apron (50m before finish)
    const innerZ = this.lanePaths.get(1)!.runningRadius - RUNNING_LINE_INSIDE_OFFSET; // 36.50
    const outerZ = innerZ + 8 * LANE_WIDTH; // 46.26
    const centerZ = (innerZ + outerZ) * 0.5;
    const totalTrackWidth = outerZ - innerZ;

    const windGroup = new THREE.Group();
    windGroup.position.set(-4.0, TRACK_SURFACE_Y, innerZ - 1.35);
    const poleGeo = new THREE.CylinderGeometry(0.035, 0.05, 1.25, 10);
    const poleMesh = new THREE.Mesh(poleGeo, pedalMat);
    poleMesh.position.y = 0.625;
    const headGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.18, 12);
    const headMesh = new THREE.Mesh(headGeo, metalMat);
    headMesh.position.y = 1.32;

    this.windGaugeCanvas = createWindGaugeTexture('+0.0 m/s', true);
    this.windGaugeTex = new THREE.CanvasTexture(this.windGaugeCanvas);
    this.windGaugeTex.colorSpace = THREE.SRGBColorSpace;
    const screenGeo = new THREE.BoxGeometry(1.15, 0.58, 0.08);
    const screenMat = new THREE.MeshBasicMaterial({ map: this.windGaugeTex });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.set(0, 0.78, 0);
    screenMesh.rotation.y = Math.PI;
    this.disposables.push(
      poleGeo,
      headGeo,
      screenGeo,
      screenMat,
      this.windGaugeTex
    );
    windGroup.add(poleMesh, headMesh, screenMesh);
    this.group.add(windGroup);

    // 5. Animated Wind Flags along home straight infield apron
    const flagPoleGeo = new THREE.CylinderGeometry(0.025, 0.03, 2.2, 8);
    const flagClothGeo = new THREE.PlaneGeometry(0.68, 0.24, 6, 1);
    flagClothGeo.translate(0.34, 0, 0);
    const flagClothMat = new THREE.MeshStandardMaterial({
      color: '#F5C542',
      roughness: 0.65,
      side: THREE.DoubleSide,
    });
    this.disposables.push(flagPoleGeo, flagClothGeo, flagClothMat);

    [
      [homeEntryX + 8, innerZ - 1.4],
      [finishLineX - 8, innerZ - 1.4],
    ].forEach(([fx, fz]) => {
      const post = new THREE.Mesh(flagPoleGeo, metalMat);
      post.position.set(fx, TRACK_SURFACE_Y + 1.1, fz);
      this.group.add(post);

      const pivot = new THREE.Group();
      pivot.position.set(fx, TRACK_SURFACE_Y + 2.08, fz);
      const cloth = new THREE.Mesh(flagClothGeo, flagClothMat);
      pivot.add(cloth);
      this.group.add(pivot);
      this.windFlags.push({ pivot, cloth });
    });

    // 6. Finish-line optical photo-finish emitter cones & laser line
    const emitterConeMat = new THREE.MeshStandardMaterial({
      color: '#F5C542',
      roughness: 0.45,
    });
    const laserGeo = new THREE.BoxGeometry(0.015, 0.015, totalTrackWidth + 0.6);
    const laserMat = new THREE.MeshBasicMaterial({
      color: '#EF4444',
      transparent: true,
      opacity: 0.55,
    });
    this.disposables.push(emitterConeMat, laserGeo, laserMat);

    const coneIn = new THREE.Mesh(coneGeo, emitterConeMat);
    coneIn.position.set(finishLineX, TRACK_SURFACE_Y + 0.17, innerZ - 0.35);
    const coneOut = new THREE.Mesh(coneGeo, emitterConeMat);
    coneOut.position.set(finishLineX, TRACK_SURFACE_Y + 0.17, outerZ + 0.35);
    const finishLaser = new THREE.Mesh(laserGeo, laserMat);
    finishLaser.position.set(finishLineX, TRACK_SURFACE_Y + 0.92, centerZ);
    this.group.add(coneIn, coneOut, finishLaser);

    stadium.scene.add(this.group);
  }

  public getLanePath(lane: number): EventLanePath200m {
    return this.lanePaths.get(lane) ?? this.lanePaths.get(1)!;
  }

  public setWind(mps: number, legal: boolean): void {
    this.windMps = mps;
    const text = `${mps >= 0 ? '+' : ''}${mps.toFixed(1)} m/s`;
    drawWindGaugeCanvas(this.windGaugeCanvas, text, legal);
    this.windGaugeTex.needsUpdate = true;
  }

  public setRecallVisible(visible: boolean, offendingLane?: number | null): void {
    this.recallConesGroup.visible = visible;
    this.blockLedMaterials.forEach((mat, lane) => {
      if (visible && offendingLane === lane) {
        mat.color.set('#EF4444');
        mat.emissive.set('#DC2626');
        mat.emissiveIntensity = 1.4;
      } else {
        mat.color.set('#22C55E');
        mat.emissive.set('#16A34A');
        mat.emissiveIntensity = 0.7;
      }
    });
  }

  public triggerGunFlash(): void {
    this.gunFxTimer = 0;
    this.gunFlashMesh.visible = true;
    this.gunSmokeMesh.visible = true;
    this.gunSmokeMesh.scale.setScalar(0.5);
    this.gunSmokeMesh.position.y = 1.75;
  }

  public updateVisuals(elapsedSeconds: number, dt: number): void {
    if (this.gunFxTimer >= 0) {
      this.gunFxTimer += dt;
      this.gunFlashMesh.visible = this.gunFxTimer < 0.14;
      if (this.gunFxTimer < 1.6) {
        this.gunSmokeMesh.visible = true;
        const p = this.gunFxTimer / 1.6;
        this.gunSmokeMesh.scale.setScalar(0.5 + p * 2.1);
        this.gunSmokeMesh.position.y = 1.75 + p * 1.4;
        (this.gunSmokeMesh.material as THREE.MeshBasicMaterial).opacity =
          0.55 * (1 - p);
      } else {
        this.gunSmokeMesh.visible = false;
        this.gunFxTimer = -1;
      }
    }

    const absWind = Math.abs(this.windMps);
    const dirSign = this.windMps >= 0 ? 1 : -1;
    this.windFlags.forEach((f, idx) => {
      const flutter =
        Math.sin(elapsedSeconds * (4.5 + absWind * 3.2) + idx) *
        (0.08 + absWind * 0.04);
      const yaw = dirSign > 0 ? 0 : Math.PI;
      f.pivot.rotation.y = yaw + flutter;
      const droop = Math.max(0.08, 0.7 - absWind * 0.24);
      f.cloth.rotation.z = -droop + Math.cos(elapsedSeconds * 7 + idx) * 0.05;
    });
  }

  public dispose(): void {
    this.stadium.scene.remove(this.group);
    this.disposables.forEach((d) => d.dispose());
  }
}
