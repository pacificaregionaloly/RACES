/**
 * Central configuration for the Men's 200m Wavesports AI event module.
 * Self-contained inside event/men200m/ with zero imports from other events.
 */

export interface Men200mRuntimeConfig {
  API_BASE_URL: string;
  API_TOKEN: string;
  RACE_ID: string;
  POLL_INTERVAL_MS: number;
  REALTIME_TRANSPORT: 'none' | 'sse' | 'ws';
  MOCK_API: boolean;
  ADMIN_MODE: boolean;
  SEED_OVERRIDE: number | null;
  CLEAN_RACE_OVERRIDE: boolean;
}

/** Set to true for local/preview dev testing; ignored in production builds (`import.meta.env.DEV` is false). */
export const MOCK_API = true;

function readSearchParams(): URLSearchParams {
  if (typeof window === 'undefined') return new URLSearchParams();
  return new URLSearchParams(window.location.search);
}

export function getMen200mConfig(): Men200mRuntimeConfig {
  const params = readSearchParams();
  const isDev = import.meta.env.DEV;

  const envBase =
    (import.meta.env.VITE_WAVESPORTS_API_BASE_URL as string | undefined) || '';
  const envToken =
    (import.meta.env.VITE_WAVESPORTS_API_TOKEN as string | undefined) || '';
  const envRaceId =
    (import.meta.env.VITE_WAVESPORTS_200M_RACE_ID as string | undefined) ||
    (import.meta.env.VITE_WAVESPORTS_RACE_ID as string | undefined) ||
    '';
  const envPoll = Number(import.meta.env.VITE_WAVESPORTS_POLL_MS || '');

  const queryBase = params.get('apiBase');
  const queryRace = params.get('race');
  const mockParam = params.get('mock');
  const queryMode = params.get('mode');
  const queryRealtime = params.get('realtime');
  const querySeedRaw = params.get('seed');
  const queryClean = params.get('clean') === '1';

  const parsedSeed =
    querySeedRaw !== null &&
    querySeedRaw.trim() !== '' &&
    Number.isInteger(Number(querySeedRaw))
      ? Number(querySeedRaw)
      : null;

  const realtime: Men200mRuntimeConfig['REALTIME_TRANSPORT'] =
    queryRealtime === 'sse' || queryRealtime === 'ws' ? queryRealtime : 'none';

  const mockAllowed =
    mockParam === '1' ? true : mockParam === '0' || Boolean(queryBase || envBase) ? false : MOCK_API;

  return {
    API_BASE_URL: (queryBase || envBase || '/api/wavesports').replace(/\/+$/, ''),
    API_TOKEN: envToken,
    RACE_ID: queryRace || envRaceId || 'men-200m-final-1',
    POLL_INTERVAL_MS:
      Number.isFinite(envPoll) && envPoll >= 500 ? envPoll : 2500,
    REALTIME_TRANSPORT: realtime,
    // Mock API is strictly dev-only and always excluded in production builds
    MOCK_API: isDev && mockAllowed,
    ADMIN_MODE: queryMode === 'admin',
    SEED_OVERRIDE: isDev ? parsedSeed : null,
    CLEAN_RACE_OVERRIDE: isDev && queryClean,
  };
}

export const STADIUM_INTEGRITY_CALLS = [
  'stadium.scene (additive EventLayer_Men200m Group attach/detach)',
  'stadium.camera & stadium.renderer (broadcast director + top-down oval PIP RenderTarget)',
  'stadium.getTrackPath(lane).pointAt(distanceMeters) (200.00 m staggered running-line derivation)',
  'stadium.addUpdateCallback(fn) (30 Hz fixed-timestep simulation + render interpolation)',
  'stadium.boards.get(name) / writeMessage(...) / setSource(...) (board text & live oval view)',
  'stadium.people.spawnPerson(...) / removePerson(...) / setPose(...) / getAll()',
  'stadium.cameras.goTo(preset)',
] as const;
