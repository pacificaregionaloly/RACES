import { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { StadiumAPI, StadiumJSONState } from '../../src/api/StadiumAPI';
import { STADIUM_CONFIG } from '../../src/config';
import '../../src/index.css';
import { SceneController } from '../../src/stadium/SceneController';
import { StadiumHUD } from '../../src/ui/StadiumHUD';
import { WebGLFallback } from '../../src/ui/WebGLFallback';
import { Men200mEventHost } from './Men200mEventHost';

const INITIAL_STATE: StadiumJSONState = {
  timeOfDay: 'sunset',
  cameraPreset: 'exterior',
  autoOrbit: false,
  crowdFillPercent: STADIUM_CONFIG.crowd.defaultFillPercent,
  crowdDensity: STADIUM_CONFIG.crowd.defaultDensity,
  cheerWave: false,
  debugCenterline: false,
  performanceMode: false,
  targetFps: 30,
  showLabels: true,
  measuredLapLengthMeters: 400.0,
  totalSeatsBuilt: STADIUM_CONFIG.stadium.seatCountTarget,
  boards: {
    eastBoard: 'demo',
    westBoard: 'demo',
    ringBoard: 'demo',
    mainScoreboard: 'demo',
  },
};

function Men200mApp() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [api, setApi] = useState<StadiumAPI | null>(null);
  const [stadiumState, setStadiumState] =
    useState<StadiumJSONState>(INITIAL_STATE);
  const [fps, setFps] = useState(30);
  const [ready, setReady] = useState(false);
  const [webglError, setWebglError] = useState<
    'unsupported' | 'context-lost' | null
  >(null);
  const [mountKey, setMountKey] = useState(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let controller: SceneController | null = null;
    try {
      controller = new SceneController(container, {
        onReady: (createdApi, initial) => {
          setApi(createdApi);
          setStadiumState(initial);
          setReady(true);
        },
        onStateChange: (next) => {
          setStadiumState(next);
        },
        onFpsUpdate: (nextFps) => {
          setFps(nextFps);
        },
        onWebGLError: (reason) => {
          setWebglError(reason);
        },
      });
    } catch {
      setWebglError('unsupported');
    }

    return () => {
      controller?.dispose();
      setApi(null);
      setReady(false);
    };
  }, [mountKey]);

  if (webglError) {
    return (
      <WebGLFallback
        reason={webglError}
        onRetry={() => {
          setWebglError(null);
          setMountKey((k) => k + 1);
        }}
      />
    );
  }

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-[#040d21] select-none">
      <div
        ref={containerRef}
        aria-label="Interactive 3D Klemonserrat Stadium Viewport"
        className="h-full w-full"
      />

      {!ready && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#040d21] text-white">
          <div className="rounded-lg border border-[#d4af37]/50 bg-[#041436] px-6 py-5 text-center shadow-2xl">
            <div className="font-display text-2xl font-extrabold tracking-wider text-[#f5c542] uppercase">
              WSTV · {STADIUM_CONFIG.venue.name} · Men&apos;s 200m
            </div>
            <p className="mt-1.5 text-xs text-slate-300">
              Loading Klemonserrat Stadium &amp; Men&apos;s 200m staggered track layer…
            </p>
          </div>
        </div>
      )}

      {ready && <StadiumHUD api={api} state={stadiumState} fps={fps} />}
      {ready && api && <Men200mEventHost api={api} />}
    </main>
  );
}

createRoot(document.getElementById('root')!).render(<Men200mApp />);
