import React, { useEffect, useMemo, useState } from 'react';
import type { StadiumAPI } from '../../src/api/StadiumAPI';
import { MockWavesportsApi200m } from './api/MockWavesportsApi';
import {
  HttpWavesportsApiClient200m,
  RealtimeWavesportsApiClient200m,
  type WavesportsApiClient200m,
} from './api/WavesportsApiClient';
import { getMen200mConfig, STADIUM_INTEGRITY_CALLS } from './config';
import {
  Men200mRaceController,
  type Men200mUIState,
} from './sim/Men200mRaceController';
import { EventPanel200m } from './ui/EventPanel200m';

interface Men200mEventHostProps {
  api: StadiumAPI;
}

export const Men200mEventHost: React.FC<Men200mEventHostProps> = ({ api }) => {
  const config = useMemo(() => getMen200mConfig(), []);
  const [controller, setController] = useState<Men200mRaceController | null>(null);
  const [uiState, setUiState] = useState<Men200mUIState | null>(null);

  useEffect(() => {
    console.info(
      '[Stadium Integrity] Men200m event initialized additively inside EventLayer_Men200m. No stadium file or object was modified. API calls used:',
      STADIUM_INTEGRITY_CALLS
    );

    let client: WavesportsApiClient200m;
    if (import.meta.env.DEV && config.MOCK_API) {
      client = new MockWavesportsApi200m({
        seedOverride: config.SEED_OVERRIDE,
        cleanRace: config.CLEAN_RACE_OVERRIDE,
      });
    } else if (config.REALTIME_TRANSPORT !== 'none') {
      client = new RealtimeWavesportsApiClient200m(
        config.API_BASE_URL,
        config.API_TOKEN,
        config.REALTIME_TRANSPORT
      );
    } else {
      client = new HttpWavesportsApiClient200m(
        config.API_BASE_URL,
        config.API_TOKEN
      );
    }

    const ctrl = new Men200mRaceController({
      stadium: api,
      apiClient: client,
      raceId: config.RACE_ID,
      pollIntervalMs: config.POLL_INTERVAL_MS,
      onUIUpdate: (next) => setUiState(next),
    });

    setController(ctrl);

    return () => {
      ctrl.dispose();
      setController(null);
    };
  }, [api, config]);

  if (!controller || !uiState) return null;

  return (
    <EventPanel200m
      controller={controller}
      uiState={uiState}
      adminModeFromUrl={config.ADMIN_MODE}
    />
  );
};
