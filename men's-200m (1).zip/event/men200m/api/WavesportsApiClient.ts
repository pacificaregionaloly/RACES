import type {
  RaceCommand200m,
  RaceResultsPayload200m,
  RaceSetupPayload200m,
  RaceStatusUpdate200m,
} from './types';

export interface WavesportsApiClient200m {
  readonly modeLabel: string;
  readonly isMock: boolean;
  fetchSetup(raceId: string, signal?: AbortSignal): Promise<RaceSetupPayload200m>;
  pollCommands(
    raceId: string,
    sinceIso?: string,
    signal?: AbortSignal
  ): Promise<RaceCommand200m[]>;
  subscribeCommands?: (
    raceId: string,
    onCommand: (command: RaceCommand200m) => void,
    onError?: (error: Error) => void
  ) => () => void;
  postStatus(raceId: string, update: RaceStatusUpdate200m): Promise<void>;
  postResults(raceId: string, results: RaceResultsPayload200m): Promise<void>;
}

export class HttpWavesportsApiClient200m implements WavesportsApiClient200m {
  public readonly modeLabel = 'WAVESPORTS HTTP API';
  public readonly isMock = false;
  private readonly baseUrl: string;
  private readonly token: string;

  constructor(baseUrl: string, token: string) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.token = token;
  }

  private buildHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  public async fetchSetup(
    raceId: string,
    signal?: AbortSignal
  ): Promise<RaceSetupPayload200m> {
    const url = `${this.baseUrl}/races/${encodeURIComponent(raceId)}/setup`;
    const res = await fetch(url, {
      method: 'GET',
      headers: this.buildHeaders(),
      signal,
    });
    if (!res.ok) {
      throw new Error(`Setup HTTP ${res.status} (${res.statusText || 'Error'})`);
    }
    return (await res.json()) as RaceSetupPayload200m;
  }

  public async pollCommands(
    raceId: string,
    sinceIso?: string,
    signal?: AbortSignal
  ): Promise<RaceCommand200m[]> {
    const qs = sinceIso ? `?since=${encodeURIComponent(sinceIso)}` : '';
    const url = `${this.baseUrl}/races/${encodeURIComponent(raceId)}/commands${qs}`;
    const res = await fetch(url, {
      method: 'GET',
      headers: this.buildHeaders(),
      signal,
    });
    if (res.status === 204 || res.status === 404) {
      return [];
    }
    if (!res.ok) {
      throw new Error(`Commands HTTP ${res.status}`);
    }
    const body = (await res.json()) as RaceCommand200m | RaceCommand200m[] | null;
    if (!body) return [];
    return Array.isArray(body) ? body : [body];
  }

  public async postStatus(
    raceId: string,
    update: RaceStatusUpdate200m
  ): Promise<void> {
    const url = `${this.baseUrl}/races/${encodeURIComponent(raceId)}/status`;
    const res = await fetch(url, {
      method: 'POST',
      headers: this.buildHeaders(),
      body: JSON.stringify({
        ...update,
        timestamp: update.timestamp ?? new Date().toISOString(),
      }),
    });
    if (!res.ok) {
      throw new Error(`Status POST HTTP ${res.status}`);
    }
  }

  public async postResults(
    raceId: string,
    results: RaceResultsPayload200m
  ): Promise<void> {
    const url = `${this.baseUrl}/races/${encodeURIComponent(raceId)}/results`;
    const res = await fetch(url, {
      method: 'POST',
      headers: this.buildHeaders(),
      body: JSON.stringify(results),
    });
    if (!res.ok) {
      throw new Error(`Results POST HTTP ${res.status}`);
    }
  }
}

/**
 * Optional Realtime Adapter (SSE or WebSocket) wrapping HttpWavesportsApiClient200m
 * for command streaming while preserving HTTP setup/status/results endpoints.
 */
export class RealtimeWavesportsApiClient200m extends HttpWavesportsApiClient200m {
  private readonly transport: 'sse' | 'ws';
  private readonly realtimeBaseUrl: string;

  constructor(
    baseUrl: string,
    token: string,
    transport: 'sse' | 'ws' = 'sse'
  ) {
    super(baseUrl, token);
    this.transport = transport;
    this.realtimeBaseUrl = baseUrl.replace(/\/+$/, '');
  }

  public subscribeCommands = (
    raceId: string,
    onCommand: (command: RaceCommand200m) => void,
    onError?: (error: Error) => void
  ): (() => void) => {
    if (this.transport === 'sse' && typeof EventSource !== 'undefined') {
      const url = `${this.realtimeBaseUrl}/races/${encodeURIComponent(raceId)}/commands/stream`;
      const es = new EventSource(url);
      es.onmessage = (ev) => {
        try {
          const parsed = JSON.parse(ev.data) as RaceCommand200m;
          if (parsed && parsed.command) onCommand(parsed);
        } catch {
          // Ignore malformed keepalive frames
        }
      };
      es.onerror = () => {
        onError?.(new Error('SSE stream disconnected'));
      };
      return () => es.close();
    }

    if (this.transport === 'ws' && typeof WebSocket !== 'undefined') {
      const wsBase = this.realtimeBaseUrl.replace(/^http/, 'ws');
      const url = `${wsBase}/races/${encodeURIComponent(raceId)}/commands/ws`;
      const ws = new WebSocket(url);
      ws.onmessage = (ev) => {
        try {
          const parsed = JSON.parse(String(ev.data)) as RaceCommand200m;
          if (parsed && parsed.command) onCommand(parsed);
        } catch {
          // Ignore non-JSON frames
        }
      };
      ws.onerror = () => {
        onError?.(new Error('WebSocket error'));
      };
      return () => ws.close();
    }

    return () => {};
  };
}
