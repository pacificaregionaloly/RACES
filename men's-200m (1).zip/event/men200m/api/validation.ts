import type { AthleteRatings200m, RaceSetupPayload200m } from './types';

export interface ValidationResult200m {
  valid: boolean;
  data?: RaceSetupPayload200m;
  errors: string[];
}

const RATING_KEYS: Array<keyof AthleteRatings200m> = [
  'reaction',
  'acceleration',
  'topSpeed',
  'speedEndurance',
  'consistency',
  'composure',
  'durability',
  'technique',
];

function isPlainObject(val: unknown): val is Record<string, unknown> {
  return typeof val === 'object' && val !== null && !Array.isArray(val);
}

function isNonEmptyString(val: unknown): val is string {
  return typeof val === 'string' && val.trim().length > 0;
}

export function validateSetupPayload200m(payload: unknown): ValidationResult200m {
  const errors: string[] = [];

  if (!isPlainObject(payload)) {
    return { valid: false, errors: ['Setup payload must be a JSON object.'] };
  }

  if (!isNonEmptyString(payload.raceId)) {
    errors.push('raceId must be a non-empty string.');
  }

  if (payload.event !== 'men_200m') {
    errors.push(
      `event must equal "men_200m" (received "${String(payload.event)}").`
    );
  }

  if (typeof payload.seed !== 'number' || !Number.isInteger(payload.seed)) {
    errors.push('seed must be an integer.');
  }

  if (!isPlainObject(payload.rules)) {
    errors.push('rules object is required.');
  } else {
    if (typeof payload.rules.falseStartDisqualifies !== 'boolean') {
      errors.push('rules.falseStartDisqualifies must be a boolean.');
    }
    if (
      typeof payload.rules.windLimitMps !== 'number' ||
      !Number.isFinite(payload.rules.windLimitMps)
    ) {
      errors.push('rules.windLimitMps must be a finite number.');
    }
  }

  if (!Array.isArray(payload.athletes)) {
    errors.push('athletes must be an array.');
  } else {
    if (payload.athletes.length < 2 || payload.athletes.length > 8) {
      errors.push(
        `athletes count must be between 2 and 8 (received ${payload.athletes.length}).`
      );
    }

    const seenLanes = new Set<number>();
    const seenIds = new Set<string>();

    payload.athletes.forEach((rawAth, idx) => {
      const prefix = `athletes[${idx}]`;
      if (!isPlainObject(rawAth)) {
        errors.push(`${prefix} must be an object.`);
        return;
      }

      if (!isNonEmptyString(rawAth.athleteId)) {
        errors.push(`${prefix}.athleteId must be a non-empty string.`);
      } else if (seenIds.has(rawAth.athleteId)) {
        errors.push(`Duplicate athleteId "${rawAth.athleteId}".`);
      } else {
        seenIds.add(rawAth.athleteId);
      }

      if (
        typeof rawAth.lane !== 'number' ||
        !Number.isInteger(rawAth.lane) ||
        rawAth.lane < 1 ||
        rawAth.lane > 8
      ) {
        errors.push(`${prefix}.lane must be an integer between 1 and 8.`);
      } else if (seenLanes.has(rawAth.lane)) {
        errors.push(`Duplicate lane ${rawAth.lane}.`);
      } else {
        seenLanes.add(rawAth.lane);
      }

      if (!isNonEmptyString(rawAth.name)) {
        errors.push(`${prefix}.name must be a non-empty string.`);
      }
      if (!isNonEmptyString(rawAth.shortName)) {
        errors.push(`${prefix}.shortName must be a non-empty string.`);
      }
      if (!isNonEmptyString(rawAth.nation)) {
        errors.push(`${prefix}.nation must be a non-empty string.`);
      }
      if (!isNonEmptyString(rawAth.nationCode)) {
        errors.push(`${prefix}.nationCode must be a non-empty string.`);
      }
      if (!isNonEmptyString(rawAth.bib)) {
        errors.push(`${prefix}.bib must be a non-empty string.`);
      }

      if (rawAth.status !== 'active' && rawAth.status !== 'dns') {
        errors.push(
          `${prefix}.status must be "active" or "dns" (received "${String(rawAth.status)}").`
        );
      }

      if (!isPlainObject(rawAth.kit)) {
        errors.push(`${prefix}.kit must be an object.`);
      } else {
        if (!isNonEmptyString(rawAth.kit.primary)) {
          errors.push(`${prefix}.kit.primary must be a color string.`);
        }
        if (!isNonEmptyString(rawAth.kit.secondary)) {
          errors.push(`${prefix}.kit.secondary must be a color string.`);
        }
        if (!isNonEmptyString(rawAth.kit.accent)) {
          errors.push(`${prefix}.kit.accent must be a color string.`);
        }
      }

      if (!isPlainObject(rawAth.ratings)) {
        errors.push(`${prefix}.ratings must be an object.`);
      } else {
        const ratings = rawAth.ratings;
        RATING_KEYS.forEach((key) => {
          const v = ratings[key];
          if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 100) {
            errors.push(`${prefix}.ratings.${key} must be a number from 0 to 100.`);
          }
        });
      }
    });
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  return {
    valid: true,
    data: payload as unknown as RaceSetupPayload200m,
    errors: [],
  };
}
