import * as THREE from 'three';
import type { StadiumAPI } from '../../src/api/StadiumAPI';
import type {
  PersonInstance,
  PersonOptions,
  PersonPoseName,
} from '../../src/people/PersonFactory';
import type { AthleteSetup } from '../api/types';
import type { AthletePoseAction } from '../ai/WavesportsAI';
import type { EventTrackLayer } from '../sim/TrackExtension';
import { applyAthletePose } from './AthleteAnimator';

interface SnapshottedRunner {
  options: PersonOptions;
  pose: PersonPoseName;
  jogDistance: number;
}

export interface EventAthleteEntity {
  setup: AthleteSetup;
  stadiumPersonId: string;
  person: PersonInstance;
  accentMesh: THREE.Mesh;
  stridePhase: number;
  currentPose: AthletePoseAction;
  currentSpeedMps: number;
  currentDistanceM: number;
}

const SKIN_TONES = ['#6D442B', '#8D5524', '#A5694F', '#C68642', '#E0AC69', '#F1C27D'];

export class AthleteManager {
  private readonly stadium: StadiumAPI;
  private readonly trackLayer: EventTrackLayer;
  private readonly entities = new Map<string, EventAthleteEntity>();
  private snapshottedIdleRunners: SnapshottedRunner[] = [];
  private runnersSuspended = false;

  constructor(stadium: StadiumAPI, trackLayer: EventTrackLayer) {
    this.stadium = stadium;
    this.trackLayer = trackLayer;
    // Remove stadium warm-up runners scattered around 200m/400m/800m immediately
    this.suspendStadiumIdleRunners();
  }

  private suspendStadiumIdleRunners(): void {
    if (this.runnersSuspended) return;
    const all = this.stadium.people.getAll();
    const toRemove: SnapshottedRunner[] = [];
    const idsToRemove: string[] = [];

    all.forEach((p) => {
      if (p.type === 'runner' && !p.id.startsWith('men100m-')) {
        toRemove.push({
          options: { ...p.options, id: p.id, jogOffsetMeters: p.jogDistance },
          pose: p.pose,
          jogDistance: p.jogDistance,
        });
        idsToRemove.push(p.id);
      }
    });

    idsToRemove.forEach((id) => this.stadium.people.removePerson(id));
    this.snapshottedIdleRunners = toRemove;
    this.runnersSuspended = true;
  }

  private restoreStadiumIdleRunners(): void {
    if (!this.runnersSuspended) return;
    this.snapshottedIdleRunners.forEach((snap) => {
      const id = this.stadium.people.spawnPerson('runner', {
        ...snap.options,
        pose: snap.pose,
        jogOffsetMeters: snap.jogDistance,
      });
      this.stadium.people.setPose(id, snap.pose);
    });
    this.snapshottedIdleRunners = [];
    this.runnersSuspended = false;
  }

  public spawnRoster(athletes: AthleteSetup[], skipIds: Set<string>): void {
    this.clearEventAthletes();
    this.suspendStadiumIdleRunners();

    const sorted = athletes.slice().sort((a, b) => a.lane - b.lane);
    sorted.forEach((ath, idx) => {
      if (ath.status === 'dns' || skipIds.has(ath.athleteId)) {
        return; // DNS athletes remain in the call room
      }

      const lp = this.trackLayer.getLanePath(ath.lane);
      const startPt = lp.pointAtRaceDistance(-0.55);
      const id = `men100m-${ath.athleteId}`;

      const spawnedId = this.stadium.people.spawnPerson('runner', {
        id,
        gender: 'men',
        name: `${ath.shortName} (${ath.nationCode})`,
        number: ath.bib,
        kitPrimary: ath.kit.primary,
        kitSecondary: ath.kit.secondary,
        skinTone: SKIN_TONES[idx % SKIN_TONES.length],
        pose: 'idle',
        position: [startPt.position.x, startPt.position.y, startPt.position.z],
        heading: startPt.heading,
      });

      const person = this.stadium.people
        .getAll()
        .find((p) => p.id === spawnedId);
      if (!person) return;

      // Apply additive accent sash from `kit.accent` onto torso
      const accentGeo = new THREE.BoxGeometry(0.365, 0.06, 0.22);
      const accentMat = new THREE.MeshStandardMaterial({
        color: ath.kit.accent,
        roughness: 0.5,
        metalness: 0.2,
      });
      const accentMesh = new THREE.Mesh(accentGeo, accentMat);
      accentMesh.position.set(0, 0.36, 0);
      person.torso.add(accentMesh);

      this.entities.set(ath.athleteId, {
        setup: ath,
        stadiumPersonId: spawnedId,
        person,
        accentMesh,
        stridePhase: (idx * 1.1) % (Math.PI * 2),
        currentPose: 'still',
        currentSpeedMps: 0,
        currentDistanceM: -0.55,
      });
    });
  }

  /**
   * Places 8 neutral standby runners still at the 100m starting line (Lanes 1-8)
   * while waiting for the Wavesports API setup payload (no invented names or ratings).
   */
  public spawnWaitingLineup(): void {
    this.clearEventAthletes();
    this.suspendStadiumIdleRunners();

    for (let lane = 1; lane <= 8; lane++) {
      const lp = this.trackLayer.getLanePath(lane);
      const startPt = lp.pointAtRaceDistance(-0.55);
      const id = `men100m-standby-${lane}`;

      const spawnedId = this.stadium.people.spawnPerson('runner', {
        id,
        gender: 'men',
        number: String(lane),
        kitPrimary: '#0033A0',
        kitSecondary: '#F8FAFC',
        skinTone: SKIN_TONES[(lane - 1) % SKIN_TONES.length],
        pose: 'idle',
        showLabel: false,
        position: [startPt.position.x, startPt.position.y, startPt.position.z],
        heading: startPt.heading,
      });

      const person = this.stadium.people
        .getAll()
        .find((p) => p.id === spawnedId);
      if (!person) continue;

      const accentGeo = new THREE.BoxGeometry(0.365, 0.06, 0.22);
      const accentMat = new THREE.MeshStandardMaterial({
        color: '#D4AF37',
        roughness: 0.5,
        metalness: 0.2,
      });
      const accentMesh = new THREE.Mesh(accentGeo, accentMat);
      accentMesh.position.set(0, 0.36, 0);
      person.torso.add(accentMesh);

      const placeholderSetup: AthleteSetup = {
        athleteId: `standby_${lane}`,
        lane,
        name: `Lane ${lane}`,
        shortName: `L${lane}`,
        nation: 'Pending API',
        nationCode: '---',
        bib: String(lane),
        kit: { primary: '#0033A0', secondary: '#F8FAFC', accent: '#D4AF37' },
        ratings: {
          reaction: 0,
          acceleration: 0,
          topSpeed: 0,
          speedEndurance: 0,
          consistency: 0,
          composure: 0,
          durability: 0,
          technique: 0,
        },
        status: 'active',
      };

      this.entities.set(placeholderSetup.athleteId, {
        setup: placeholderSetup,
        stadiumPersonId: spawnedId,
        person,
        accentMesh,
        stridePhase: 0,
        currentPose: 'still',
        currentSpeedMps: 0,
        currentDistanceM: -0.55,
      });
    }
  }

  public updateAthleteState(
    athleteId: string,
    distanceM: number,
    lateralOffsetM: number,
    speedMps: number,
    pose: AthletePoseAction,
    dt: number,
    elapsedSec: number,
    visible = true
  ): void {
    const ent = this.entities.get(athleteId);
    if (!ent) return;

    ent.person.root.visible = visible;
    if (!visible) return;

    const lp = this.trackLayer.getLanePath(ent.setup.lane);
    const pt = lp.pointAtRaceDistance(distanceM, lateralOffsetM);
    ent.person.root.position.copy(pt.position);
    ent.person.root.rotation.y = pt.heading;

    // Cadence scales with speed
    if (pose === 'sprint' || pose === 'stumble' || pose === 'lean_finish') {
      const cadence = 6.5 + speedMps * 1.45;
      ent.stridePhase += cadence * dt;
    } else if (pose === 'pull_up_injured') {
      ent.stridePhase += Math.max(2.0, speedMps * 1.1) * dt;
    }

    ent.currentPose = pose;
    ent.currentSpeedMps = speedMps;
    ent.currentDistanceM = distanceM;

    applyAthletePose(
      ent.person,
      pose,
      elapsedSec,
      speedMps,
      ent.stridePhase
    );
  }

  public getEntity(athleteId: string): EventAthleteEntity | undefined {
    return this.entities.get(athleteId);
  }

  public getAllEntities(): EventAthleteEntity[] {
    return Array.from(this.entities.values());
  }

  public getLeaderPosition(): THREE.Vector3 | null {
    let best: EventAthleteEntity | null = null;
    this.entities.forEach((ent) => {
      if (!ent.person.root.visible) return;
      if (!best || ent.currentDistanceM > best.currentDistanceM) {
        best = ent;
      }
    });
    return best ? (best as EventAthleteEntity).person.root.position.clone() : null;
  }

  public clearEventAthletes(): void {
    this.entities.forEach((ent) => {
      ent.person.torso.remove(ent.accentMesh);
      ent.accentMesh.geometry.dispose();
      (ent.accentMesh.material as THREE.Material).dispose();
      this.stadium.people.removePerson(ent.stadiumPersonId);
    });
    this.entities.clear();
  }

  public cleanupAll(): void {
    this.clearEventAthletes();
    this.restoreStadiumIdleRunners();
  }
}
