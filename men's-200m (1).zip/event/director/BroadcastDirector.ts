import * as THREE from 'three';
import type { StadiumAPI } from '../../src/api/StadiumAPI';
import type { RaceState } from '../api/types';

export type EventCameraId =
  | 'auto'
  | 'startingLine'
  | 'startingLineStands'
  | 'blocksHeadOn'
  | 'trackingRail'
  | 'finishLine'
  | 'photoFinish'
  | 'replayCam'
  | 'overhead';

export class BroadcastDirector {
  private readonly stadium: StadiumAPI;
  private directorEnabled = true;
  private userTookOrbitControl = false;
  private selectedCamera: EventCameraId = 'auto';

  private readonly currentPos = new THREE.Vector3();
  private readonly currentTarget = new THREE.Vector3();
  private readonly desiredPos = new THREE.Vector3();
  private readonly desiredTarget = new THREE.Vector3();
  private currentFov = 44;
  private desiredFov = 44;
  private initializedCamera = false;

  private readonly onUserPointer = () => {
    if (!this.userTookOrbitControl) {
      this.userTookOrbitControl = true;
      this.onStateChangeCallback?.();
    }
  };

  private onStateChangeCallback?: () => void;

  constructor(stadium: StadiumAPI, onStateChange?: () => void) {
    this.stadium = stadium;
    this.onStateChangeCallback = onStateChange;

    const dom = stadium.renderer.domElement;
    dom.addEventListener('pointerdown', this.onUserPointer, { passive: true });
    dom.addEventListener('wheel', this.onUserPointer, { passive: true });
    dom.addEventListener('touchstart', this.onUserPointer, { passive: true });
  }

  public isDirectorEnabled(): boolean {
    return this.directorEnabled;
  }

  public hasUserOverride(): boolean {
    return this.userTookOrbitControl;
  }

  public getSelectedCamera(): EventCameraId {
    return this.selectedCamera;
  }

  public setDirectorEnabled(enabled: boolean): void {
    this.directorEnabled = enabled;
    if (enabled) {
      this.userTookOrbitControl = false;
      this.initializedCamera = false;
    }
    this.onStateChangeCallback?.();
  }

  public selectCamera(camId: EventCameraId): void {
    this.selectedCamera = camId;
    this.directorEnabled = true;
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    if (camId === 'overhead') {
      this.stadium.cameras.goTo('overhead');
    }
    this.onStateChangeCallback?.();
  }

  public resetView(): void {
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    this.selectedCamera = 'auto';
    this.directorEnabled = true;
    this.stadium.cameras.goTo('homeStraight');
    this.onStateChangeCallback?.();
  }

  public update(
    raceState: RaceState,
    raceClockSec: number,
    isReplay: boolean,
    leaderPos: THREE.Vector3 | null,
    dt: number
  ): void {
    if (!this.directorEnabled || this.userTookOrbitControl) {
      return;
    }

    const activeCam = this.resolveActiveCamera(raceState, raceClockSec, isReplay);
    const lx = leaderPos ? leaderPos.x : -57.8;

    switch (activeCam) {
      case 'startingLine':
        this.desiredPos.set(-51.5, 2.75, 49.4);
        this.desiredTarget.set(-58.1, 0.95, 41.38);
        this.desiredFov = 42;
        break;
      case 'startingLineStands':
        this.desiredPos.set(-64.0, 15.5, 69.0);
        this.desiredTarget.set(-53.0, 1.0, 41.38);
        this.desiredFov = 44;
        break;
      case 'blocksHeadOn':
        this.desiredPos.set(-46.5, 1.65, 41.38);
        this.desiredTarget.set(-58.2, 0.85, 41.38);
        this.desiredFov = 38;
        break;
      case 'trackingRail': {
        const clampedX = THREE.MathUtils.clamp(lx, -58, 43);
        this.desiredPos.set(clampedX - 1.2, 2.55, 53.8);
        this.desiredTarget.set(clampedX + 2.4, 1.05, 41.38);
        this.desiredFov = 40;
        break;
      }
      case 'finishLine':
        this.desiredPos.set(47.2, 2.35, 49.4);
        this.desiredTarget.set(42.195, 1.05, 41.38);
        this.desiredFov = 35;
        break;
      case 'photoFinish':
        this.desiredPos.set(42.195, 1.85, 53.0);
        this.desiredTarget.set(42.195, 0.9, 40.5);
        this.desiredFov = 24;
        break;
      case 'replayCam': {
        const clampedX = THREE.MathUtils.clamp(lx, -58, 45);
        this.desiredPos.set(50.5, 1.65, 34.4);
        this.desiredTarget.set(clampedX, 1.0, 41.38);
        this.desiredFov = 36;
        break;
      }
      case 'overhead':
        this.desiredPos.set(-8.0, 62.0, 41.45);
        this.desiredTarget.set(-8.0, 0.0, 41.38);
        this.desiredFov = 46;
        break;
    }

    if (!this.initializedCamera) {
      this.currentPos.copy(this.stadium.camera.position);
      this.currentTarget.copy(this.desiredTarget);
      this.currentFov = this.stadium.camera.fov;
      this.initializedCamera = true;
    }

    const lambda = activeCam === 'trackingRail' ? 8.5 : 5.5;
    const alpha = 1 - Math.exp(-lambda * Math.max(0.001, dt));
    this.currentPos.lerp(this.desiredPos, alpha);
    this.currentTarget.lerp(this.desiredTarget, alpha);
    this.currentFov += (this.desiredFov - this.currentFov) * alpha;

    this.stadium.camera.position.copy(this.currentPos);
    if (Math.abs(this.stadium.camera.fov - this.currentFov) > 0.02) {
      this.stadium.camera.fov = this.currentFov;
      this.stadium.camera.updateProjectionMatrix();
    }
    this.stadium.camera.lookAt(this.currentTarget);
  }

  private resolveActiveCamera(
    raceState: RaceState,
    raceClockSec: number,
    isReplay: boolean
  ): Exclude<EventCameraId, 'auto'> {
    if (this.selectedCamera !== 'auto') {
      return this.selectedCamera;
    }
    if (isReplay) {
      return raceClockSec > 7.5 ? 'photoFinish' : 'replayCam';
    }
    switch (raceState) {
      case 'WAITING_FOR_API':
      case 'SETUP_RECEIVED':
      case 'VALIDATED':
        return 'startingLineStands';
      case 'ATHLETES_ON_TRACK':
      case 'READY':
      case 'ON_YOUR_MARKS':
      case 'SET':
      case 'FALSE_START_RECALL':
        return 'startingLine';
      case 'RUNNING':
        if (raceClockSec < 2.2) return 'blocksHeadOn';
        if (raceClockSec < 8.1) return 'trackingRail';
        return 'finishLine';
      case 'FINISHED':
      case 'RESULTS_POSTED':
        return 'finishLine';
      default:
        return 'blocksHeadOn';
    }
  }

  public dispose(): void {
    const dom = this.stadium.renderer.domElement;
    dom.removeEventListener('pointerdown', this.onUserPointer);
    dom.removeEventListener('wheel', this.onUserPointer);
    dom.removeEventListener('touchstart', this.onUserPointer);
  }
}
