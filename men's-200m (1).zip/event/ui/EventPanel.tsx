import React, { useState } from 'react';
import {
  AlertTriangle,
  Camera,
  ChevronDown,
  ChevronUp,
  Eye,
  Film,
  Monitor,
  Play,
  RotateCcw,
  ShieldCheck,
  Volume2,
  VolumeX,
  Wind,
} from 'lucide-react';
import { STADIUM_INTEGRITY_CALLS } from '../config';
import type { EventCameraId } from '../director/BroadcastDirector';
import type { RaceController, RaceControllerUIState } from '../sim/RaceController';

interface EventPanelProps {
  controller: RaceController;
  uiState: RaceControllerUIState;
  adminModeFromUrl: boolean;
}

const CAMERA_OPTIONS: Array<{ id: EventCameraId; label: string }> = [
  { id: 'auto', label: 'Auto' },
  { id: 'startingLine', label: 'Starting Line Cam' },
  { id: 'startingLineStands', label: 'Starting Line Stands View' },
  { id: 'blocksHeadOn', label: 'Blocks' },
  { id: 'trackingRail', label: 'Rail' },
  { id: 'finishLine', label: 'Finish' },
  { id: 'photoFinish', label: 'Photo' },
  { id: 'replayCam', label: 'Replay' },
  { id: 'overhead', label: 'Overhead' },
];

export const EventPanel: React.FC<EventPanelProps> = ({
  controller,
  uiState,
  adminModeFromUrl,
}) => {
  const [expanded, setExpanded] = useState(true);
  const [showIntegrity, setShowIntegrity] = useState(false);

  const isAdminVisible = adminModeFromUrl || uiState.allowManualStart;
  const canManualStart =
    uiState.allowManualStart && uiState.raceState === 'READY';
  const canReplay =
    uiState.raceState === 'FINISHED' ||
    uiState.raceState === 'RESULTS_POSTED' ||
    uiState.isReplay;

  const stateColor =
    uiState.raceState === 'WAITING_FOR_API'
      ? uiState.apiConnectionState === 'error'
        ? 'bg-red-600 text-white'
        : 'bg-amber-500 text-slate-950'
      : uiState.raceState === 'FALSE_START_RECALL'
      ? 'bg-red-600 text-white'
      : uiState.raceState === 'RUNNING'
      ? 'bg-emerald-500 text-slate-950'
      : 'bg-[#0033a0] text-[#f5c542]';

  const apiStatusDot =
    uiState.apiConnectionState === 'connected'
      ? 'bg-emerald-400'
      : uiState.apiConnectionState === 'error'
      ? 'bg-red-500'
      : 'bg-amber-400';

  const windDisplay =
    uiState.windMps !== null
      ? `${uiState.windMps >= 0 ? '+' : ''}${uiState.windMps.toFixed(1)} m/s (${
          uiState.windLegal ? 'LEGAL' : 'AIDED'
        })`
      : 'Waiting…';

  // Read-only athlete rows: sorted by rank if finished, otherwise by lane
  const resultsById = new Map(
    (uiState.plan?.results ?? []).map((r) => [r.athleteId, r])
  );
  const athletesList = (uiState.setup?.athletes ?? [])
    .slice()
    .sort((a, b) => a.lane - b.lane);

  return (
    <>
      {/* Compact Top-Left Wavesports AI Event Panel (positioned below StadiumHUD header) */}
      <aside
        aria-label="Wavesports AI Men's 100m Broadcast Panel"
        className="pointer-events-auto fixed left-3 sm:left-4 top-[104px] sm:top-[110px] z-20 w-[356px] max-w-[calc(100vw-24px)] rounded-xl border border-[#d4af37]/45 bg-[#041029]/95 text-white shadow-2xl"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between gap-2 border-b border-white/10 px-3 py-2">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span
                aria-hidden="true"
                className={`inline-block h-2 w-2 shrink-0 rounded-full ${apiStatusDot}`}
              />
              <h2 className="truncate font-display text-sm font-bold tracking-wide uppercase text-[#f5c542]">
                Wavesports AI – Men&apos;s 100m
              </h2>
            </div>
            {uiState.isMock && (
              <span className="mt-1 inline-block rounded bg-amber-400 px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-slate-950">
                MOCK API – DEV ONLY
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => controller.setMuted(!uiState.muted)}
              aria-label={uiState.muted ? 'Unmute Race Audio' : 'Mute Race Audio'}
              className="rounded p-1 text-slate-300 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
            >
              {uiState.muted ? (
                <VolumeX className="h-3.5 w-3.5" />
              ) : (
                <Volume2 className="h-3.5 w-3.5" />
              )}
            </button>
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              aria-label={expanded ? 'Collapse Men 100m Panel' : 'Expand Men 100m Panel'}
              className="rounded p-1 text-slate-300 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
            >
              {expanded ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>

        {/* Summary Strip (always visible even when collapsed) */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 text-[11px] bg-[#07183c]/80">
          <span className={`rounded px-1.5 py-0.5 font-mono font-bold ${stateColor}`}>
            {uiState.raceState}
          </span>
          <span className="font-mono text-base font-bold text-[#f5c542]">
            {uiState.raceClockSec.toFixed(2)}s
          </span>
          <span className="flex items-center gap-1 font-mono text-[10px] text-[#7dd3fc]">
            <Wind className="h-3 w-3" />
            {windDisplay}
          </span>
        </div>

        {/* Always-Visible Starting Line Camera Quick Buttons */}
        <div
          className="flex flex-wrap items-center gap-1.5 border-t border-white/10 bg-[#051434] px-3 py-1.5"
          role="group"
          aria-label="Starting Line Cameras"
        >
          <button
            type="button"
            onClick={() => controller.selectCamera('startingLine')}
            aria-pressed={uiState.selectedCamera === 'startingLine'}
            className={`flex items-center justify-center gap-1 rounded-md px-2.5 py-1 text-[10.5px] font-semibold whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              uiState.selectedCamera === 'startingLine'
                ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/70'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Camera className="h-3 w-3 shrink-0 text-[#f5c542]" />
            <span>Starting Line Cam</span>
          </button>
          <button
            type="button"
            onClick={() => controller.selectCamera('startingLineStands')}
            aria-pressed={uiState.selectedCamera === 'startingLineStands'}
            className={`flex flex-1 items-center justify-center gap-1 rounded-md px-2.5 py-1 text-[10.5px] font-semibold whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              uiState.selectedCamera === 'startingLineStands'
                ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/70'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Eye className="h-3 w-3 shrink-0 text-[#7dd3fc]" />
            <span>Starting Line Stands View</span>
          </button>
        </div>

        {expanded && (
          <div className="max-h-[calc(100vh-370px)] space-y-2.5 overflow-y-auto custom-scroll border-t border-white/10 p-3 text-xs">
            {/* API Connection & Race Metadata */}
            <div className="grid grid-cols-2 gap-1.5 rounded-lg border border-white/10 bg-[#07183c] p-2 text-[11px]">
              <div>
                <div className="text-[10px] uppercase text-slate-400">API State</div>
                <div className="font-semibold text-white">
                  {uiState.apiConnectionState === 'connected'
                    ? 'Connected'
                    : uiState.apiConnectionState === 'error'
                    ? 'Error / Retry'
                    : 'Waiting for Wavesports API…'}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Race ID</div>
                <div className="truncate font-mono text-[#7dd3fc]">{uiState.raceId}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Seed</div>
                <div className="font-mono text-[#f5c542]">
                  {uiState.seed !== null ? uiState.seed : '—'}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Mode</div>
                <div className="font-semibold text-slate-200">
                  {isAdminVisible ? 'Admin Broadcast' : 'Viewer Broadcast'}
                </div>
              </div>
            </div>

            {/* Waiting / Error Alert */}
            {uiState.apiError && (
              <div
                role="alert"
                className="flex items-start gap-2 rounded-lg border border-red-400/50 bg-red-950/70 p-2 text-[11px] text-red-100"
              >
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                <span>{uiState.apiError}</span>
              </div>
            )}

            {uiState.raceState === 'WAITING_FOR_API' && !uiState.apiError && (
              <div className="rounded-lg border border-[#d4af37]/35 bg-[#07183c] p-2.5 text-center text-[11px] text-slate-200">
                Waiting for Wavesports API… Stadium remains live &amp; orbitable.
                Athletes will spawn once validated setup arrives.
              </div>
            )}

            {/* Read-only Athletes List */}
            {athletesList.length > 0 && (
              <div>
                <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-300">
                  <span>Official Field (Read-Only)</span>
                  <span>{athletesList.length} Lanes</span>
                </div>
                <ul className="space-y-1">
                  {athletesList.map((ath) => {
                    const res = resultsById.get(ath.athleteId);
                    const showOutcome =
                      uiState.raceState === 'FINISHED' ||
                      uiState.raceState === 'RESULTS_POSTED';
                    return (
                      <li
                        key={ath.athleteId}
                        className="flex items-center justify-between rounded bg-[#07183c] px-2 py-1 text-[11px]"
                      >
                        <div className="flex min-w-0 items-center gap-1.5">
                          <span
                            className="inline-block h-3 w-1.5 rounded-sm"
                            style={{ backgroundColor: ath.kit.primary }}
                          />
                          <span className="font-mono font-bold text-[#f5c542]">
                            L{ath.lane}
                          </span>
                          <span className="truncate font-semibold text-white">
                            {ath.shortName}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {ath.nationCode}
                          </span>
                        </div>
                        <span className="shrink-0 font-mono text-[10px] text-[#7dd3fc]">
                          {showOutcome && res
                            ? res.status === 'finished'
                              ? `${res.rank}. ${res.time?.toFixed(2)}s`
                              : res.status
                            : ath.status === 'dns'
                            ? 'DNS'
                            : ath.personalBest
                            ? `PB ${ath.personalBest.toFixed(2)}`
                            : `#${ath.bib}`}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {/* Live Incident Log */}
            <div>
              <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-300">
                Incident Log ({uiState.visibleIncidents.length})
              </div>
              {uiState.visibleIncidents.length === 0 ? (
                <div className="rounded bg-[#07183c]/60 px-2 py-1.5 text-[11px] text-slate-400">
                  No incidents reported.
                </div>
              ) : (
                <ul className="space-y-1">
                  {uiState.visibleIncidents.map((inc, i) => (
                    <li
                      key={`${inc.code}-${inc.attempt}-${i}`}
                      className="rounded border border-amber-400/30 bg-amber-950/35 px-2 py-1 text-[11px] text-amber-100"
                    >
                      <span className="font-mono text-[10px] font-bold text-[#f5c542]">
                        [{inc.code}]
                      </span>{' '}
                      {inc.detail}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Track Camera Views (Always Accessible) */}
            <div className="space-y-1.5 rounded-lg border border-white/10 bg-[#07183c] p-2">
              <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-300">
                <span className="flex items-center gap-1">
                  <Camera className="h-3 w-3 text-[#f5c542]" />
                  100m Cameras
                </span>
                {uiState.directorUserOverride && (
                  <span className="text-[10px] text-sky-300">Orbit Override</span>
                )}
              </div>
              <div className="flex flex-wrap gap-1" role="group" aria-label="Men 100m Camera Angles">
                {CAMERA_OPTIONS.map((cam) => {
                  const active = uiState.selectedCamera === cam.id;
                  return (
                    <button
                      key={cam.id}
                      type="button"
                      onClick={() => controller.selectCamera(cam.id)}
                      aria-pressed={active}
                      className={`rounded px-2 py-0.5 text-[10px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                        active
                          ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/50'
                          : 'bg-[#041029] text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {cam.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Admin Controls (ONLY visible when allowManualStart or ?mode=admin) */}
            {isAdminVisible && (
              <div className="space-y-2 rounded-lg border border-[#d4af37]/40 bg-[#07183c] p-2.5">
                <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-[#f5c542]">
                  <span>Broadcast Admin Controls</span>
                  {uiState.directorUserOverride && (
                    <span className="text-[10px] text-sky-300">Orbit Override</span>
                  )}
                </div>

                {/* Manual start allowed ONLY if setup.allowManualStart === true */}
                {uiState.allowManualStart && (
                  <button
                    type="button"
                    disabled={!canManualStart}
                    onClick={() => controller.triggerManualStart()}
                    aria-label="Manual Admin Start Race"
                    className={`flex w-full items-center justify-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-bold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                      canManualStart
                        ? 'bg-[#d4af37] text-[#041029] hover:bg-[#f5c542]'
                        : 'cursor-not-allowed bg-slate-800 text-slate-500'
                    }`}
                  >
                    <Play className="h-3.5 w-3.5" />
                    <span>Manual Start (API Override)</span>
                  </button>
                )}

                {/* Auto Director Toggle & Reset View */}
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      controller.setDirectorEnabled(!uiState.directorEnabled)
                    }
                    aria-pressed={uiState.directorEnabled}
                    aria-label="Toggle Broadcast Camera Director"
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                      uiState.directorEnabled && !uiState.directorUserOverride
                        ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/50'
                        : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Camera className="h-3 w-3" />
                    <span>Director {uiState.directorEnabled ? 'ON' : 'OFF'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => controller.resetView()}
                    aria-label="Reset Broadcast Camera View"
                    className="flex items-center gap-1 rounded bg-[#041029] px-2 py-1 text-[11px] font-semibold text-slate-200 hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-[#f5c542]"
                  >
                    <RotateCcw className="h-3 w-3" />
                    <span>Reset View</span>
                  </button>
                </div>

                {/* Replay Controls (1x / 0.25x Slow Motion) + Live Mini-View */}
                <div className="flex flex-wrap gap-1.5 pt-1 border-t border-white/10">
                  <button
                    type="button"
                    disabled={!canReplay}
                    onClick={() => controller.startReplay(1)}
                    aria-label="Play 1x Replay"
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                      canReplay
                        ? 'bg-[#041029] text-white hover:bg-[#0033a0]'
                        : 'cursor-not-allowed bg-slate-900 text-slate-600'
                    }`}
                  >
                    <Film className="h-3 w-3" />
                    <span>Replay 1x</span>
                  </button>
                  <button
                    type="button"
                    disabled={!canReplay}
                    onClick={() => controller.startReplay(0.25)}
                    aria-label="Play 0.25x Slow Motion Replay"
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                      canReplay
                        ? 'bg-[#041029] text-[#f5c542] hover:bg-[#0033a0]'
                        : 'cursor-not-allowed bg-slate-900 text-slate-600'
                    }`}
                  >
                    <Eye className="h-3 w-3" />
                    <span>0.25x Slow</span>
                  </button>
                  {uiState.isReplay && (
                    <button
                      type="button"
                      onClick={() => controller.stopReplay()}
                      aria-label="Stop Replay"
                      className="rounded bg-red-700 px-2 py-1 text-[11px] font-semibold text-white hover:bg-red-600"
                    >
                      Stop
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => controller.setLiveMiniView(!uiState.liveMiniView)}
                  aria-pressed={uiState.liveMiniView}
                  aria-label="Toggle Live 3D Mini-View on West Board"
                  className={`flex w-full items-center justify-center gap-1.5 rounded px-2 py-1 text-[10px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                    uiState.liveMiniView
                      ? 'bg-[#0033a0] text-[#f5c542]'
                      : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <Monitor className="h-3 w-3" />
                  <span>
                    West Board 3D Mini-View: {uiState.liveMiniView ? 'ON' : 'OFF'}
                  </span>
                </button>

                {/* Dev-only Mock API triggers */}
                {uiState.isMock && (
                  <div className="flex flex-wrap gap-1 border-t border-white/10 pt-1.5">
                    <button
                      type="button"
                      disabled={uiState.raceState !== 'READY'}
                      onClick={() => controller.devMockTrigger('start')}
                      className="flex-1 rounded bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white disabled:opacity-40"
                    >
                      Mock: Start Cmd
                    </button>
                    <button
                      type="button"
                      onClick={() => controller.devMockTrigger('reset')}
                      className="rounded bg-slate-700 px-2 py-1 text-[10px] font-bold text-white"
                    >
                      Reset
                    </button>
                    <button
                      type="button"
                      onClick={() => controller.devMockTrigger('new_seed')}
                      className="rounded bg-slate-700 px-2 py-1 text-[10px] font-bold text-white"
                    >
                      New Seed
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Stadium Integrity Panel Toggle */}
            <div className="border-t border-white/10 pt-1.5">
              <button
                type="button"
                onClick={() => setShowIntegrity((v) => !v)}
                aria-expanded={showIntegrity}
                className="flex w-full items-center justify-between text-[10px] font-semibold text-slate-300 hover:text-white"
              >
                <span className="flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3 text-emerald-400" />
                  Stadium Integrity (Read-Only Verified)
                </span>
                <span>{showIntegrity ? 'Hide' : 'Show'}</span>
              </button>
              {showIntegrity && (
                <ul className="mt-1.5 space-y-0.5 rounded bg-[#07183c] p-2 font-mono text-[9.5px] text-slate-300">
                  <li className="text-emerald-300">
                    No stadium file or object was modified.
                  </li>
                  {STADIUM_INTEGRITY_CALLS.map((c) => (
                    <li key={c}>• {c}</li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </aside>

      {/* WSTV Broadcast Lower-Third Commentary Bar */}
      {uiState.setup && (
        <div
          aria-live="polite"
          className="pointer-events-none fixed bottom-[164px] lg:bottom-[116px] left-1/2 z-10 w-[680px] max-w-[calc(100vw-24px)] -translate-x-1/2 rounded-lg border border-[#d4af37]/50 bg-[#041029]/95 px-3.5 py-2 shadow-2xl"
        >
          <div className="flex items-center justify-between gap-2 text-[10px] font-bold tracking-wider uppercase text-[#f5c542]">
            <span>WSTV COMMENTARY · {uiState.latestHeadline}</span>
            {uiState.isReplay && (
              <span className="rounded bg-red-600 px-1.5 py-0.5 text-white">
                REPLAY {uiState.replaySpeed}x
              </span>
            )}
          </div>
          <p className="mt-0.5 text-xs font-medium text-white">
            {uiState.latestCaption}
          </p>
        </div>
      )}
    </>
  );
};
