/**
 * Incident probability defaults for Men's 100m (Wavesports AI).
 * All probabilities are per-athlete or per-attempt rates in [0, 1] and
 * can be overridden (or zeroed out for a clean race) via `setup.incidentOverrides`.
 */

export interface IncidentConfigRates {
  /** Base probability per athlete of a false start (< 0.100s or pre-gun movement). */
  falseStartBaseRate: number;
  /** Base probability per athlete of a stumbled / slipped push-off from blocks. */
  stumbledStartRate: number;
  /** Base probability per athlete of falling / tripping in the early drive phase. */
  fallOrTripRate: number;
  /** Base probability per athlete of an in-race hamstring/muscle injury pull-up. */
  injuryPullUpRate: number;
  /** Base probability per athlete of stepping over a lane line. */
  laneViolationRate: number;
  /** Probability of an adjacent-lane brush/collision when a runner stumbles. */
  collisionBrushRate: number;
  /** Very rare call-room withdrawal after setup validation. */
  lateDnsRate: number;
  /** Very rare starting block slip requiring a recall & restart. */
  equipmentBlockSlipRate: number;
  /** Chance of an inspired breakout run exceeding base ratings. */
  breakoutPerformanceRate: number;
  /** Maximum false-start / equipment recalls before forcing a clean start. */
  maxRecalls: number;
}

export const DEFAULT_INCIDENT_RATES: IncidentConfigRates = {
  falseStartBaseRate: 0.028,
  stumbledStartRate: 0.035,
  fallOrTripRate: 0.012,
  injuryPullUpRate: 0.01,
  laneViolationRate: 0.008,
  collisionBrushRate: 0.006,
  lateDnsRate: 0.005,
  equipmentBlockSlipRate: 0.007,
  breakoutPerformanceRate: 0.045,
  maxRecalls: 3,
};

export function mergeIncidentRates(
  overrides?: Partial<IncidentConfigRates> | null
): IncidentConfigRates {
  if (!overrides) {
    return { ...DEFAULT_INCIDENT_RATES };
  }
  const merged: IncidentConfigRates = { ...DEFAULT_INCIDENT_RATES };
  (Object.keys(DEFAULT_INCIDENT_RATES) as Array<keyof IncidentConfigRates>).forEach(
    (key) => {
      const val = overrides[key];
      if (typeof val === 'number' && Number.isFinite(val)) {
        merged[key] = key === 'maxRecalls' ? Math.max(0, Math.min(5, Math.round(val))) : Math.max(0, Math.min(1, val));
      }
    }
  );
  return merged;
}
